(()=>{
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const CFG=window.GAME_CONFIG||{};
const STORE='ar_dimension_hunt_v3';
const OLD_STORE='ar_dimension_hunt_v2';
const rarityLabel={common:'ทั่วไป',rare:'หายาก',epic:'มหากาพย์',legendary:'ตำนาน'};
const rarityRank={common:1,rare:2,epic:3,legendary:4};

const CRAFT_RECIPES=[
 {id:'mix_fire_tonic',name:'น้ำยาพลังเพลิง',icon:'🔥',ingredients:{s01_01:1,s09_01:1},desc:'คริสตัลเปลวไฟ + มัดสมุนไพร',effect:'radar_boost',effectText:'เรดาร์ +50 ม. 30 นาที',durationMin:30},
 {id:'mix_frost_core',name:'แกนน้ำแข็ง',icon:'❄️',ingredients:{s01_02:1,s06_01:1},desc:'คริสตัลน้ำแข็ง + ผลึกดาวน้ำแข็ง',effect:'cooldown_half',effectText:'คูลดาวน์เหลือ 50% 30 นาที',durationMin:30},
 {id:'mix_storm_orb',name:'ลูกแก้วพายุ',icon:'⚡',ingredients:{s01_08:1,s07_07:1},desc:'คริสตัลสายฟ้า + ลูกแก้วสายฟ้า',effect:'capture_boost',effectText:'รัศมีเก็บ +6 ม. 30 นาที',durationMin:30},
 {id:'mix_star_orb',name:'ลูกแก้วดารา',icon:'🌟',ingredients:{s06_02:1,s07_05:1},desc:'เศษดาวจักรวาล + ลูกแก้วอาคม',effect:'star_sight',effectText:'แผนที่ไกลขึ้น +100 ม. 30 นาที',durationMin:30},
 {id:'mix_ancient_core',name:'แกนจักรกลโบราณ',icon:'⚙️',ingredients:{s04_02:1,s05_04:1},desc:'ฟอสซิลไทรโลไบต์ + เฟืองโบราณ',effect:'trader_bonus',effectText:'NPC ให้เหรียญมิติ ×2 30 นาที',durationMin:30},
 {id:'mix_solar_seed',name:'เมล็ดสุริยะ',icon:'🌻',ingredients:{s08_07:1,s01_07:1},desc:'ผลสุริยะ + คริสตัลสุริยะ',effect:'radar_small',effectText:'เรดาร์ +30 ม. 60 นาที',durationMin:60},
 {id:'mix_moon_elixir',name:'น้ำยาจันทรา',icon:'🌙',ingredients:{s03_01:1,s07_01:1},desc:'เหรียญจันทรา + ลูกแก้วจันทรา',effect:'capture_small',effectText:'รัศมีเก็บ +3 ม. 60 นาที',durationMin:60},
 {id:'mix_knowledge_seal',name:'ตราความรู้มิติ',icon:'📜',ingredients:{s12_06:1,s15_02:1},desc:'หนังสือความรู้โบราณ + ตราคัมภีร์ดวงดาว',effect:'math_hint',effectText:'เปิดคำใบ้โจทย์ 30 นาที',durationMin:30},
 {id:'mix_portal_key',name:'กุญแจพอร์ทัล',icon:'🗝️',ingredients:{s14_01:1,s14_02:1},desc:'ลูกบาศก์พอร์ทัล + คริสตัลมิติ',effect:'portal',effectText:'ใช้เปิดประตูมิติ 1 ครั้ง'},
 {id:'mix_phoenix_flame',name:'เปลวเพลิงฟีนิกซ์',icon:'🪶',ingredients:{s18_06:1,s13_01:1},desc:'ขนนกฟีนิกซ์ + ทับทิมเพลิง',effect:'legendary_sight',effectText:'ตรวจจับ Legendary ได้ไกลขึ้น 30 นาที',durationMin:30},
 {id:'mix_cosmic_compass',name:'เข็มทิศจักรวาล',icon:'🧭',ingredients:{s06_04:1,s14_03:1},desc:'สูตรลับ',effect:'star_sight',effectText:'แผนที่ไกลขึ้น +100 ม. 60 นาที',durationMin:60,secret:true},
 {id:'mix_lucky_prism',name:'ปริซึมโชคดี',icon:'🔮',ingredients:{s13_06:1,s14_06:1},desc:'สูตรลับ',effect:'trader_bonus',effectText:'NPC ให้เหรียญมิติ ×2 60 นาที',durationMin:60,secret:true},
 {id:'mix_time_sand',name:'ทรายเวลามิติ',icon:'⏳',ingredients:{s14_08:1,s18_07:1},desc:'สูตรลับ',effect:'cooldown_half',effectText:'คูลดาวน์เหลือ 50% 60 นาที',durationMin:60,secret:true}
];
function recipeById(id){return CRAFT_RECIPES.find(x=>x.id===id);}

const STUDENT_ROSTER={"401":{"name":"กนกศักดิ์ เกตุแก้ว","grade":4,"internal":"401"},"402":{"name":"วาทิวุทธ คล้ายสอน","grade":4,"internal":"402"},"403":{"name":"มณฑรัชต์ บุญนำ","grade":4,"internal":"403"},"404":{"name":"กนกพร หงษ์ทอง","grade":4,"internal":"404"},"405":{"name":"กนกวรรณ หงษ์ทอง","grade":4,"internal":"405"},"406":{"name":"ณัฐมน บัวเกิด","grade":4,"internal":"406"},"407":{"name":"บุณนิสา ประเคนทอง","grade":4,"internal":"407"},"408":{"name":"วริศรา ทรัพย์สิน","grade":4,"internal":"408"},"409":{"name":"สุภิญญา แกมนิรัตน์","grade":4,"internal":"409"},"410":{"name":"อริสา บวบนา","grade":4,"internal":"410"},"411":{"name":"กันต์ฤทัย เหลืองทอง","grade":4,"internal":"411"},"412":{"name":"มณีกรณ์ บำรุงจิตต์","grade":4,"internal":"412"},"501":{"name":"เกียรติศักดิ์ จันทร์แดง","grade":5,"internal":"501"},"502":{"name":"กวิน โชติช่วง","grade":5,"internal":"502"},"503":{"name":"จิรายุ บุญพรม","grade":5,"internal":"503"},"504":{"name":"ธนภูมิ ลุทภาพ","grade":5,"internal":"504"},"505":{"name":"นภสินธิ์ ว่องวัฒนะกุลชัย","grade":5,"internal":"505"},"506":{"name":"ปัญจกรณ์ แก้วมาก","grade":5,"internal":"506"},"507":{"name":"พีระพล ทันใจ","grade":5,"internal":"507"},"508":{"name":"ภานุพงศ์ แจ้งถิ่นป่า","grade":5,"internal":"508"},"509":{"name":"รุ่งทิวา เจริญรุ่ง","grade":5,"internal":"509"},"510":{"name":"วชิรวิชญ์ หงษ์วิลัย","grade":5,"internal":"510"},"511":{"name":"อนุวัฒน์ วิชิตชัย","grade":5,"internal":"511"},"512":{"name":"กวินธิดา สืบมา","grade":5,"internal":"512"},"513":{"name":"ณัฐกานต์ ภักดีปัญญา","grade":5,"internal":"513"},"514":{"name":"ณัฐนิชา แก้วกำพล","grade":5,"internal":"514"},"515":{"name":"ทักษพร โตปรางค์","grade":5,"internal":"515"},"516":{"name":"ปรียาภัทร บุญพรม","grade":5,"internal":"516"},"517":{"name":"ปิยากร สืบมา","grade":5,"internal":"517"},"518":{"name":"พัชรนันท์ บัวขันธ์","grade":5,"internal":"518"},"519":{"name":"ยลดา พันสวัสดิ์","grade":5,"internal":"519"},"520":{"name":"ชุติกาญจน์ เพ็ชรเกิด","grade":5,"internal":"520"},"521":{"name":"ชยพล ขันเงิน","grade":5,"internal":"521"},"522":{"name":"ทอมมี่ เวบสเตอร์","grade":5,"internal":"522"},"523":{"name":"สุรีย์ภรณ์ คำฝอย","grade":5,"internal":"523"},"601":{"name":"กรรชัย โชติช่วง","grade":6,"internal":"601"},"602":{"name":"กิตติศักดิ์ ดอนนอก","grade":6,"internal":"602"},"603":{"name":"ฉัตรนรินทร์ บุญพรม","grade":6,"internal":"603"},"604":{"name":"พุฒิเทพ เบ้าทอง","grade":6,"internal":"604"},"605":{"name":"ภควัต หงษ์สี","grade":6,"internal":"605"},"606":{"name":"ภัคพงษ์ ขันนาค","grade":6,"internal":"606"},"607":{"name":"อมร ทองรุ่ง","grade":6,"internal":"607"},"608":{"name":"ศิริวรรณ ระโหฐาน","grade":6,"internal":"608"},"609":{"name":"ปริยฉัตร เพิงขุนทด","grade":6,"internal":"609"},"610":{"name":"ปาริชาติ นากันหา","grade":6,"internal":"610"},"611":{"name":"วาสนา แสงนารี","grade":6,"internal":"611"},"612":{"name":"นาวิน ปิ่นมาศ","grade":6,"internal":"612"},"613":{"name":"ณัฐณิชา ทรัพย์ส่ง","grade":6,"internal":"613"},"A":{"name":"ครูทดสอบ A","grade":4,"internal":"TA"},"B":{"name":"ครูทดสอบ B","grade":6,"internal":"TB"}};
const apiUrl=String(CFG.API_URL||'').trim();
const state={
  student:null,studentCode:'',grade:4,demo:false,pos:null,acc:null,speed:0,lastPos:null,
  spawns:[],inventory:{},collected:{},todayCount:0,todayStats:{common:0,rare:0,epic:0,legendary:0},
  leaderboard:[],activeSpawn:null,question:null,answer:'',watch:null,camera:null,teacherCode:'2468',loginRole:'student',teacherSession:false,boundary:null,
  cloud:/^https:\/\//.test(apiUrl),syncing:false,lastSync:0,mapRange:150,view:'radar',
  walk:{date:'',meters:0},legendarySeen:{},publicConfig:{},lastCollectRarity:null,crafted:{},tokens:0,activeEffects:{}
};

function todayKey(){return new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Bangkok'});}
function save(){
  localStorage.setItem(STORE,JSON.stringify({student:state.student,studentCode:state.studentCode,grade:state.grade,spawns:state.spawns,inventory:state.inventory,collected:state.collected,todayCount:state.todayCount,todayStats:state.todayStats,teacherCode:state.teacherCode,mapRange:state.mapRange,walk:state.walk,legendarySeen:state.legendarySeen,loginRole:state.loginRole,teacherSession:state.teacherSession,boundary:state.boundary,crafted:state.crafted,tokens:state.tokens,activeEffects:state.activeEffects}));
}
function load(){
  try{
    let raw=localStorage.getItem(STORE)||localStorage.getItem(OLD_STORE)||'{}';
    let d=JSON.parse(raw); Object.assign(state,d);
  }catch(e){}
  if(!state.todayStats)state.todayStats={common:0,rare:0,epic:0,legendary:0};
  if(!state.walk||state.walk.date!==todayKey())state.walk={date:todayKey(),meters:0};
  if(!state.legendarySeen)state.legendarySeen={};
  if(!state.crafted)state.crafted={};
  if(!Number.isFinite(+state.tokens))state.tokens=0;
  if(!state.activeEffects)state.activeEffects={};
}
load();

function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function show(id){$$('.screen').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');}
function toast(t){let x=$('#toast');x.textContent=t;x.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>x.classList.remove('show'),2600);}
function rad(deg){return deg*Math.PI/180;}
function hav(a,b){if(!a||!b)return 99999;let R=6371000,dLat=rad(b.lat-a.lat),dLon=rad(b.lng-a.lng);let q=Math.sin(dLat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(q));}
function bearing(a,b){let y=Math.sin(rad(b.lng-a.lng))*Math.cos(rad(b.lat)),x=Math.cos(rad(a.lat))*Math.sin(rad(b.lat))-Math.sin(rad(a.lat))*Math.cos(rad(b.lat))*Math.cos(rad(b.lng-a.lng));return (Math.atan2(y,x)*180/Math.PI+360)%360;}
function itemById(id){return ITEMS.find(i=>i.id===id);}
function r(a,b){return Math.floor(Math.random()*(b-a+1))+a;}
function setSync(kind='local'){let d=$('#syncDot');if(!d)return;d.className='syncDot '+kind;d.title=kind==='ok'?'ซิงก์ออนไลน์แล้ว':kind==='busy'?'กำลังซิงก์':kind==='error'?'ซิงก์ไม่สำเร็จ':'ใช้ข้อมูลในเครื่อง';}
function sumBag(){return Object.values(state.inventory).reduce((a,b)=>a+(+b||0),0);}
function uniqueBag(){return Object.keys(state.inventory).filter(k=>+state.inventory[k]>0).length;}
function effectActive(key){return !!(state.activeEffects&&Number(state.activeEffects[key])>Date.now());}
function effectiveRadarRange(){let base=130;if(effectActive('radar_boost'))base+=50;if(effectActive('radar_small'))base+=30;if(effectActive('star_sight'))base+=100;return base;}
function effectiveMapRange(){let base=+state.mapRange||150;if(effectActive('star_sight'))base+=100;return base;}
function effectiveCollectRadius(sp){let r=+sp.radius||18;if(effectActive('capture_boost'))r+=6;if(effectActive('capture_small'))r+=3;return r;}
function effectiveCooldown(sp){let c=+sp.cooldown||86400000;if(effectActive('cooldown_half'))c*=.5;return c;}
function remainingText(ts){let ms=Math.max(0,Number(ts)-Date.now()),m=Math.ceil(ms/60000);return m>=60?Math.floor(m/60)+' ชม. '+(m%60)+' นาที':m+' นาที';}

function setPf(id,status,label){
  const el=$(id); if(!el)return; el.className='pf '+status; if(label)el.textContent=label;
}
function pingApi(){
  return new Promise((resolve,reject)=>{
    if(!apiUrl)return reject(new Error('ยังไม่ได้ตั้ง API URL'));
    const cb='__ardh_ping_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    const sc=document.createElement('script');
    const timer=setTimeout(()=>finish(new Error('timeout')),10000);
    function finish(err,data){clearTimeout(timer);try{delete window[cb]}catch(_){window[cb]=undefined;}sc.remove();err?reject(err):resolve(data);}
    window[cb]=d=>d&&d.ok?finish(null,d):finish(new Error((d&&d.error)||'API error'));
    sc.src=apiUrl+(apiUrl.includes('?')?'&':'?')+'callback='+encodeURIComponent(cb)+'&_ping='+Date.now();
    sc.async=true;sc.onerror=()=>finish(new Error('network'));document.head.appendChild(sc);
  });
}
async function runPreflight(){
  const secure=window.isSecureContext||location.hostname==='localhost'||location.hostname==='127.0.0.1';
  const gps=!!navigator.geolocation;
  const cam=!!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia);
  setPf('#pfHttps',secure?'ok':'bad',(secure?'✅':'❌')+' HTTPS');
  setPf('#pfGps',gps?'ok':'bad',(gps?'✅':'❌')+' GPS');
  setPf('#pfCamera',cam&&secure?'ok':cam?'warn':'bad',((cam&&secure)?'✅':cam?'⚠️':'❌')+' กล้อง AR');
  const hint=$('#preflightHint');
  let apiOk=false;
  setPf('#pfApi','pending','⏳ ระบบกลาง');
  try{const d=await pingApi();apiOk=!!d.ok;setPf('#pfApi','ok','✅ ระบบกลาง');}
  catch(e){setPf('#pfApi','bad','❌ ระบบกลาง');}
  const all=secure&&gps&&cam&&apiOk;
  if(hint){
    hint.className=all?'good':'bad';
    hint.textContent=all?'พร้อมใช้งานบนมือถือแล้ว • เมื่อกดเริ่ม เบราว์เซอร์จะขอสิทธิ์ตำแหน่งและกล้อง':'ยังมีบางรายการไม่พร้อม • ใช้ HTTPS บนมือถือและอนุญาตตำแหน่ง/กล้องเมื่อระบบถาม';
  }
  return {secure,gps,cam,apiOk};
}


function apiJsonp(action,payload={}){
  return new Promise((resolve,reject)=>{
    const cb='__ardh_cb_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    const script=document.createElement('script');
    const timer=setTimeout(()=>finish(new Error('API timeout')),18000);
    function finish(err,data){
      clearTimeout(timer);try{delete window[cb]}catch(_){window[cb]=undefined;}script.remove();
      if(err)reject(err);else resolve(data);
    }
    window[cb]=(data)=>{if(!data||!data.ok)return finish(new Error((data&&data.error)||'API error'));finish(null,data);};
    const packed=encodeURIComponent(JSON.stringify({action,...payload}));
    script.src=apiUrl+(apiUrl.includes('?')?'&':'?')+'callback='+encodeURIComponent(cb)+'&payload='+packed+'&_t='+Date.now();
    script.async=true;script.onerror=()=>finish(new Error('เชื่อม API ไม่สำเร็จ'));
    document.head.appendChild(script);
  });
}
async function api(action,payload={}){
  if(!state.cloud)throw new Error('offline');
  state.syncing=true;setSync('busy');
  try{
    let data;
    try{
      const res=await fetch(apiUrl,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,...payload}),redirect:'follow'});
      if(!res.ok)throw new Error('HTTP '+res.status);
      data=await res.json();
      if(!data.ok)throw new Error(data.error||'API error');
    }catch(fetchErr){
      // Google Apps Script อาจถูกเบราว์เซอร์บล็อก CORS เมื่อเกมอยู่คนละโดเมน
      // ใช้ JSONP fallback เพื่อให้ Vercel/GitHub Pages/เว็บโรงเรียนใช้งานได้จริง
      data=await apiJsonp(action,payload);
    }
    state.lastSync=Date.now();setSync('ok');return data;
  }catch(e){setSync('error');throw e;}finally{state.syncing=false;}
}

function weightedItem(){
  let n=Math.random(),rar=n<.72?'common':n<.90?'rare':n<.98?'epic':'legendary';
  let pool=ITEMS.filter(x=>x.rarity===rar);return pool[Math.floor(Math.random()*pool.length)]||ITEMS[0];
}
function defaultSpawns(center){
  let pts=[],radii=[18,28,38,50,65,80,95,110],n=24;
  for(let i=0;i<n;i++){
    let ang=(i/n)*Math.PI*2+(i%3)*.22,rr=radii[i%radii.length],dLat=(rr*Math.cos(ang))/111111,dLng=(rr*Math.sin(ang))/(111111*Math.cos(rad(center.lat))),it=weightedItem();
    let schedule=it.rarity==='legendary'?{startHour:11,endHour:13,dayMode:'weekdays'}:{startHour:0,endHour:24,dayMode:'all'};
    pts.push({id:'p'+Date.now()+'_'+i,lat:center.lat+dLat,lng:center.lng+dLng,itemId:it.id,radius:18,cooldown:86400000,active:true,label:'',...schedule});
  }
  return pts;
}

function applyBootstrap(d){
  if(d.student){state.student=d.student.name||state.student;state.grade=+d.student.grade||state.grade;}
  if(Array.isArray(d.spawns))state.spawns=d.spawns;
  if(d.inventory)state.inventory=d.inventory;
  if(d.crafted)state.crafted=d.crafted;
  if(Number.isFinite(+d.tokens))state.tokens=+d.tokens;
  if(d.activeEffects)state.activeEffects=d.activeEffects;
  if(d.collected)state.collected=d.collected;
  if(Number.isFinite(+d.todayCount))state.todayCount=+d.todayCount;
  if(d.todayStats)state.todayStats=Object.assign({common:0,rare:0,epic:0,legendary:0},d.todayStats);
  if(Array.isArray(d.leaderboard))state.leaderboard=d.leaderboard;
  if(d.config)state.publicConfig=d.config;
  save();
}
async function cloudBootstrap(silent=false){
  if(!state.cloud||!state.studentCode)return;
  try{let d=await api('bootstrap',{studentCode:state.studentCode,name:state.student,grade:state.grade});applyBootstrap(d);if(!silent)toast('☁️ ซิงก์ข้อมูลโรงเรียนแล้ว');render();}
  catch(e){if(!silent)toast('ใช้ข้อมูลในเครื่องชั่วคราว');}
}

async function start(demo=false){
  let code=$('#studentCode').value.trim(),name=$('#studentName').value.trim()||'นักสำรวจ';
  if(!demo&&state.cloud&&code.length<2)return toast('กรุณาใส่รหัสนักเรียน');
  state.student=name;state.studentCode=code||('DEMO-'+Math.random().toString(36).slice(2,7).toUpperCase());state.grade=+$('#grade').value;state.demo=demo;
  if(state.walk.date!==todayKey())state.walk={date:todayKey(),meters:0};
  save();$('#hello').textContent=name+' • ป.'+state.grade;show('main');
  if(state.cloud&&!demo)await cloudBootstrap();
  if(demo){state.pos={lat:16,lng:100,t:Date.now()};state.acc=5;if(!state.spawns.length)state.spawns=defaultSpawns(state.pos);render();}
  else startGPS();
}
function cleanStudentCode(v){v=String(v||'').trim().toUpperCase().replace(/[^0-9AB]/g,'');if(v==='A'||v==='B')return v;return v.replace(/\D/g,'').slice(0,3);} 
function showStudentLookup(code){const box=$('#studentLookup'),s=STUDENT_ROSTER[code];if(s){$('#studentName').value=s.name;$('#grade').value=String(s.grade);if(box){box.dataset.type='ok';box.innerHTML=`<b>✅ ${esc(s.name)}</b><small>ชั้นประถมศึกษาปีที่ ${s.grade} • รหัส ${esc(code)}</small>`;}return s;}$('#studentName').value='';$('#grade').value='4';if(box){box.dataset.type=code?'error':'pending';box.innerHTML=code?`<b>❌ ไม่พบรหัส ${esc(code)}</b><small>ตรวจสอบรหัสที่ได้รับจากครู</small>`:`<b>🔎 กรอกรหัสนักเรียน</b><small>นักเรียนใช้รหัส 3 หลัก • ครูทดสอบใช้ A หรือ B</small>`;}return null;}
$('#studentCode')?.addEventListener('input',()=>{let c=cleanStudentCode($('#studentCode').value);$('#studentCode').value=c;showStudentLookup(c);});
$('#startBtn').onclick=async()=>{let typed=cleanStudentCode($('#studentCode').value),s=showStudentLookup(typed);if(!s)return toast('ไม่พบรหัสนักเรียนนี้');$('#studentCode').value=s.internal||typed;$('#studentName').value=s.name;$('#grade').value=String(s.grade);await start(false);};$('#demoBtn').onclick=()=>start(true);
function setLoginRole(role){state.loginRole=role;save();let student=role!=='teacher';$('#studentModeBtn')?.classList.toggle('active',student);$('#teacherModeBtn')?.classList.toggle('active',!student);$('#studentPane')?.classList.toggle('active',student);$('#teacherPane')?.classList.toggle('active',!student);$('#login').classList.toggle('teacherSelected',!student);let note=$('#loginFootnote');if(note)note.textContent=student?'การใช้ GPS และกล้องต้องเปิดผ่าน HTTPS หรือ localhost • เมื่อเชื่อม GAS ข้อมูลจะซิงก์กับ Google Sheet':'ครูสามารถเข้าสู่โหมดควบคุมเพื่อปล่อยวัตถุหลายชิ้น ตั้งรัศมี และกำหนดขอบเขตพื้นที่เล่น';}
async function enterTeacherMode(demo=false){let code=($('#teacherCodeQuick')?.value||'').trim();if(!demo&&!code)return toast('กรุณากรอกรหัสครู');state.teacherSession=true;state.student='ครูผู้ควบคุม';state.studentCode='T';state.grade=6;state.demo=demo;save();$('#hello').textContent='โหมดครูผู้ควบคุม';show('main');if(demo){state.pos=state.pos||{lat:16,lng:100,t:Date.now()};state.acc=5;if(!state.spawns.length)state.spawns=defaultSpawns(state.pos);render();}else startGPS();panel('settings');setTimeout(()=>teacherLogin($('#panelBody'),code),80);}
$('#studentModeBtn')?.addEventListener('click',()=>setLoginRole('student'));
$('#teacherModeBtn')?.addEventListener('click',()=>setLoginRole('teacher'));
$('#teacherEnterBtn')?.addEventListener('click',()=>enterTeacherMode(false));
$('#teacherDemoBtn')?.addEventListener('click',()=>enterTeacherMode(true));
if($('#recheckBtn'))$('#recheckBtn').onclick=()=>runPreflight();
runPreflight();
if(state.student){$('#studentName').value=state.student;let vis=state.studentCode==='TA'?'A':state.studentCode==='TB'?'B':(state.studentCode||'');$('#studentCode').value=vis;$('#grade').value=state.grade;showStudentLookup(cleanStudentCode(vis));}
setLoginRole(state.loginRole||'student');
$('#modeBadge').textContent=state.cloud?'☁️ เชื่อม Google Sheet':'📱 โหมดในเครื่อง';$('#modeBadge').classList.toggle('cloud',state.cloud);setSync(state.cloud?'ok':'local');

function countWalk(prev,now,coords){
  if(!prev||state.demo)return;
  if(state.walk.date!==todayKey())state.walk={date:todayKey(),meters:0};
  let dt=(now.t-prev.t)/1000,dist=hav(prev,now),acc=coords.accuracy||99,spd=coords.speed;
  let plausible=dt>0&&dt<30&&dist>1&&dist<Math.max(35,dt*4)&&acc<=40&&(spd==null||spd<=3.5);
  if(plausible){state.walk.meters=Math.min(20000,(+state.walk.meters||0)+dist);save();}
}
function startGPS(){
  if(!navigator.geolocation){toast('อุปกรณ์นี้ไม่รองรับ GPS');return;}
  $('#statusText').textContent='กำลังขอพิกัด GPS...';
  state.watch=navigator.geolocation.watchPosition(p=>{
    let now={lat:p.coords.latitude,lng:p.coords.longitude,t:Date.now()};state.acc=Math.round(p.coords.accuracy||0);
    if(state.lastPos){let dt=(now.t-state.lastPos.t)/1000;if(dt>0)state.speed=p.coords.speed??(hav(state.lastPos,now)/dt);countWalk(state.lastPos,now,p.coords);}
    state.lastPos=now;state.pos=now;
    if(!state.spawns.length&&!state.cloud){state.spawns=defaultSpawns(now);save();toast('สร้างจุดทดลองรอบตำแหน่งปัจจุบันแล้ว');}
    render();
  },()=>{toast('เปิด GPS ไม่สำเร็จ • ใช้โหมดทดลองได้');$('#statusText').textContent='ไม่พบ GPS';},{enableHighAccuracy:true,maximumAge:2000,timeout:15000});
}

function scheduleActive(s,now=new Date()){
  let mode=String(s.dayMode||'all'),day=now.getDay();
  if(mode==='weekdays'&&(day===0||day===6))return false;
  if(mode==='weekend'&&day!==0&&day!==6)return false;
  let h=now.getHours()+now.getMinutes()/60,start=Number(s.startHour),end=Number(s.endHour);
  if(!Number.isFinite(start))start=0;if(!Number.isFinite(end))end=24;
  if(start===end)return true;
  if(start<end)return h>=start&&h<end;
  return h>=start||h<end;
}
function scheduleText(s){
  let start=Number.isFinite(+s.startHour)?+s.startHour:0,end=Number.isFinite(+s.endHour)?+s.endHour:24,mode=String(s.dayMode||'all');
  let days=mode==='weekdays'?'จ.-ศ.':mode==='weekend'?'ส.-อา.':'ทุกวัน';
  if(start===0&&end===24)return days+' • ทั้งวัน';
  return `${days} • ${String(start).padStart(2,'0')}:00–${String(end).padStart(2,'0')}:00`;
}
function spawnStatus(s){
  let d=hav(state.pos,s),last=+state.collected[s.id]||0,ready=Date.now()-last>effectiveCooldown(s),windowActive=scheduleActive(s);
  return {d,ready,windowActive};
}
function allEntries(){return state.spawns.filter(s=>s.active!==false).map(s=>({...s,...spawnStatus(s),item:itemById(s.itemId)})).filter(x=>x.item).sort((a,b)=>a.d-b.d);}
function todayRarePlus(){let t=state.todayStats||{};return (+t.rare||0)+(+t.epic||0)+(+t.legendary||0);}
function missionGoals(){return {collect:+CFG.DAILY_COLLECT_GOAL||3,rare:+CFG.DAILY_RARE_GOAL||1,walk:+((CFG.DAILY_WALK_GOAL_BY_GRADE||{})[state.grade]||160)};}
function renderMissions(){
  let g=missionGoals(),collect=+state.todayCount||0,rare=todayRarePlus(),walk=Math.round(+state.walk.meters||0);
  let rows=[
    {icon:'🎒',label:`เก็บของ ${g.collect} ชิ้น`,v:collect,g:g.collect},
    {icon:'💜',label:`พบ Rare ขึ้นไป ${g.rare} ชิ้น`,v:rare,g:g.rare},
    {icon:'🚶',label:`เดินสำรวจ ${g.walk} เมตร`,v:walk,g:g.walk}
  ];
  let done=rows.filter(x=>x.v>=x.g).length,pct=rows.reduce((a,x)=>a+Math.min(1,x.v/x.g),0)/rows.length*100;
  $('#missionBar').style.width=pct+'%';$('#missionText').textContent=done===3?'สำเร็จครบทุกภารกิจแล้ว! 🎉':`สำเร็จ ${done}/3 ภารกิจ`;
  $('#missionList').innerHTML=rows.map(x=>`<div class="missionRow ${x.v>=x.g?'done':''}"><span>${x.v>=x.g?'✅':x.icon}</span><b>${esc(x.label)}</b><span>${Math.min(x.v,x.g)}/${x.g}</span></div>`).join('');
}

function render(){
  if(!state.pos)return;
  let entries=allEntries();
  $('#statusText').textContent=state.demo?'โหมดทดลอง • จำลองตำแหน่ง':state.cloud?'กำลังสำรวจ • ออนไลน์':'กำลังสำรวจ • ในเครื่อง';
  $('#gpsAccuracy').textContent=state.demo?'Demo':`GPS ±${state.acc||'?'} m`;$('#bagCount').textContent=sumBag();
  renderMissions();renderLegendary(entries);renderRadar(entries);renderMap(entries);renderNearby(entries);
}
function renderRadar(entries){
  let radar=$('#radar');radar.querySelectorAll('.ping').forEach(x=>x.remove());
  let radarRange=effectiveRadarRange();entries.filter(x=>x.ready&&x.windowActive&&x.d<radarRange).slice(0,18).forEach(e=>{let ang=rad(bearing(state.pos,e)),rr=Math.min(46,e.d/radarRange*46),x=50+Math.sin(ang)*rr,y=50-Math.cos(ang)*rr,p=document.createElement('div');p.className='ping '+e.item.rarity;p.style.left=x+'%';p.style.top=y+'%';p.title=e.item.name;radar.appendChild(p);});
}
function renderMap(entries){
  let svg=$('#missionMap');if(!svg)return;let range=effectiveMapRange(),cx=160,cy=160,scale=128/range;
  let parts=['<circle class="mapGrid" cx="160" cy="160" r="43"/><circle class="mapGrid" cx="160" cy="160" r="86"/><circle class="mapGrid" cx="160" cy="160" r="128"/><line class="mapAxis" x1="32" y1="160" x2="288" y2="160"/><line class="mapAxis" x1="160" y1="32" x2="160" y2="288"/>'];
  entries.filter(e=>e.d<=range*1.05).slice(0,40).forEach(e=>{
    let dLat=(e.lat-state.pos.lat)*111111,dLng=(e.lng-state.pos.lng)*111111*Math.cos(rad(state.pos.lat));
    let x=cx+dLng*scale,y=cy-dLat*scale,radSize=e.item.rarity==='legendary'?8:e.item.rarity==='epic'?7:e.item.rarity==='rare'?6:5;
    x=Math.max(24,Math.min(296,x));y=Math.max(24,Math.min(296,y));
    parts.push(`<circle class="mapSpawn ${e.item.rarity} ${e.windowActive&&e.ready?'':'closed'}" data-spawn="${esc(e.id)}" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${radSize}"/>`);
  });
  parts.push('<circle class="mapMe" cx="160" cy="160" r="7"/>');parts.push('<path d="M160 145 L154 158 L166 158 Z" fill="#fff"/>');
  svg.innerHTML=parts.join('');
  svg.querySelectorAll('[data-spawn]').forEach(n=>n.addEventListener('click',()=>{let e=entries.find(x=>x.id===n.dataset.spawn);if(!e)return;$('#mapHint').textContent=`${(e.d<25||effectActive('star_sight'))?e.item.name:'สัญญาณ '+rarityLabel[e.item.rarity]} • ${Math.round(e.d)} ม. • ${e.windowActive?(e.ready?'พร้อมเก็บ':'รอเกิดใหม่'):'ยังไม่ถึงเวลา'} • ${scheduleText(e)}`;}));
}
function renderNearby(entries){
  let near=$('#nearby');near.innerHTML='';
  entries.slice(0,5).forEach(e=>{
    let can=e.ready&&e.windowActive&&e.d<=(+e.radius||18),card=document.createElement('div');
    card.className='nearCard '+(!e.windowActive?'closed ':'')+(e.item.rarity==='legendary'?'legendaryCard':'');
    let label=e.d<20?esc(e.item.name):'??? สัญญาณ '+rarityLabel[e.item.rarity];
    let sub=!e.windowActive?`ยังไม่ถึงเวลา • ${scheduleText(e)}`:!e.ready?'เก็บแล้ว • รอเกิดใหม่':`${Math.round(e.d)} เมตร${e.label?' • '+esc(e.label):''}`;
    card.innerHTML=`<img src="${e.item.img}" alt="${esc(e.item.name)}"><div class="meta"><b>${label}</b><span class="rarityChip ${e.item.rarity}">${rarityLabel[e.item.rarity]}</span><small>${sub}</small></div><button ${can?'':'disabled'}>${can?'เปิด AR':!e.windowActive?'ปิดอยู่':'เดินเข้าใกล้'}</button>`;
    card.querySelector('button').onclick=()=>openAR(e);near.appendChild(card);
  });
  if(!entries.length)near.innerHTML='<div class="emptyState">ยังไม่มีจุดเกิดของ • ให้ครูตั้งจุดในโหมดครู</div>';
}
function renderLegendary(entries){
  let lim=(+CFG.LEGENDARY_ALERT_RADIUS_M||250)+(effectActive('legendary_sight')?500:0);
  let lg=entries.find(e=>e.item.rarity==='legendary'&&e.windowActive&&e.ready&&e.d<=lim);
  let banner=$('#legendaryBanner');
  if(!lg){banner.classList.add('hidden');return;}
  banner.classList.remove('hidden');$('#legendaryText').textContent=`สัญญาณอยู่ห่างประมาณ ${Math.round(lg.d)} เมตร${lg.label?' • '+lg.label:''}`;
  if(!state.legendarySeen[lg.id]){state.legendarySeen[lg.id]=Date.now();save();if(navigator.vibrate)navigator.vibrate([100,70,160]);toast('👑 ตรวจพบสัญญาณ Legendary!');}
}

$('#radarViewBtn').onclick=()=>{state.view='radar';$('#radarViewBtn').classList.add('active');$('#mapViewBtn').classList.remove('active');$('#radarWrap').classList.remove('hidden');$('#mapWrap').classList.add('hidden');};
$('#mapViewBtn').onclick=()=>{state.view='map';$('#mapViewBtn').classList.add('active');$('#radarViewBtn').classList.remove('active');$('#mapWrap').classList.remove('hidden');$('#radarWrap').classList.add('hidden');render();};
$('#mapRange').value=String(state.mapRange||150);$('#mapRange').onchange=e=>{state.mapRange=+e.target.value||150;save();render();};

function moveDemo(){
  if(!state.demo||!state.pos)return;let nearest=allEntries().filter(x=>x.windowActive&&x.ready).find(x=>x.d>4);
  if(!nearest)return toast('อยู่ใกล้จุดเกิดแล้ว');let before=nearest.d,f=Math.min(.45,10/nearest.d);
  state.pos={lat:state.pos.lat+(nearest.lat-state.pos.lat)*f,lng:state.pos.lng+(nearest.lng-state.pos.lng)*f,t:Date.now()};state.walk.meters=(+state.walk.meters||0)+Math.min(10,before);save();render();toast('จำลองเดินเข้าใกล้ '+Math.max(0,Math.round(before-10))+' ม.');
}
function nearestReady(){return allEntries().filter(x=>x.ready&&x.windowActive)[0];}
$('#arNav').onclick=()=>{let n=nearestReady();if(!n)return toast('ยังไม่พบสัญญาณที่พร้อมเกิด');let er=effectiveCollectRadius(n);if(n.d>er)return toast('ต้องเข้าใกล้อีก '+Math.ceil(n.d-er)+' เมตร');openAR(n);};
async function openAR(sp){
  if(!sp.windowActive)return toast('วัตถุนี้ยังไม่ถึงเวลาเกิด');if(!sp.ready)return toast('จุดนี้ยังรอเกิดใหม่');
  state.activeSpawn=sp;show('arScreen');$('#arItemImg').src=sp.item.img;$('#arDistance').textContent=Math.round(sp.d)+' m';$('#arRarity').textContent=rarityLabel[sp.item.rarity];$('#arRarity').className='glass pill rarityChip '+sp.item.rarity;$('#arHint').textContent='พบ '+sp.item.name+' • แตะเพื่อปลดล็อก';$('#arScreen').classList.toggle('legendaryAR',sp.item.rarity==='legendary');
  try{state.camera=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});$('#camera').srcObject=state.camera;$('.cameraFallback').style.display='none';}
  catch(e){$('.cameraFallback').style.display='block';toast(window.isSecureContext?'ใช้ AR จำลอง เนื่องจากเปิดกล้องไม่ได้':'ต้องเปิดผ่าน HTTPS เพื่อใช้กล้อง AR');}
}
function closeAR(){if(state.camera){state.camera.getTracks().forEach(t=>t.stop());state.camera=null;}$('#arScreen').classList.remove('legendaryAR');show('main');render();}
$('#closeAr').onclick=closeAR;
$('#arItemBtn').onclick=()=>{if(state.speed>1.8&&!state.demo)return toast('เพื่อความปลอดภัย กรุณาหยุดเดินก่อนแก้โจทย์');makeQuestion();$('#mathModal').classList.add('show');};

function makeQuestion(){
  const rarity=state.activeSpawn?.item?.rarity||'common';
  let a,b,c,q,ans;
  if(rarity==='common'){
    if(Math.random()<.5){a=r(10,69);b=r(10,99-a);ans=a+b;q=`${a} + ${b} = ?`;}
    else{a=r(20,99);b=r(10,a-1);ans=a-b;q=`${a} − ${b} = ?`;}
  }else if(rarity==='rare'){
    if(Math.random()<.5){do{a=r(10,59);b=r(10,99-a);}while((a%10)+(b%10)<10);ans=a+b;q=`${a} + ${b} = ?`;}
    else{do{a=r(20,99);b=r(10,a-1);}while((a%10)>=(b%10));ans=a-b;q=`${a} − ${b} = ?`;}
  }else if(rarity==='epic'){
    a=r(2,12);b=r(2,12);ans=a*b;q=`${a} × ${b} = ?`;
  }else{
    a=r(2,12);b=r(2,12);c=r(10,49);if(Math.random()<.5){ans=a*b+c;q=`${a} × ${b} + ${c} = ?`;}else{let prod=a*b;if(prod<c){[prod,c]=[c,prod]}ans=prod-c;q=`${a} × ${b} − ${c} = ?`;if(ans<0){c=r(10,Math.max(10,a*b));ans=a*b-c;q=`${a} × ${b} − ${c} = ?`;}}
  }
  state.question={q,ans,rarity};state.answer='';$('#question').textContent=q;renderAnswer();
}
function renderAnswer(){$('#answer').textContent=state.answer.padEnd(3,'_').split('').join(' ');}
let keypad=$('.keypad');[1,2,3,4,5,6,7,8,9,'⌫',0,'✓'].forEach(v=>{let b=document.createElement('button');b.textContent=v;if(v==='⌫')b.className='del';if(v==='✓')b.className='ok';b.onclick=()=>{if(v==='⌫')state.answer=state.answer.slice(0,-1);else if(v==='✓')checkAnswer();else if(state.answer.length<3)state.answer+=v;renderAnswer();};keypad.appendChild(b);});
function checkAnswer(){if(state.answer==='')return;if(+state.answer===state.question.ans){$('#mathModal').classList.remove('show');collect();}else{toast('ยังไม่ถูก ลองคำนวณอีกครั้ง');$('.modalCard').animate([{transform:'translateX(-8px)'},{transform:'translateX(8px)'},{transform:'translateX(0)'}],{duration:250});state.answer='';renderAnswer();}}
$('#cancelMath').onclick=()=>$('#mathModal').classList.remove('show');

function completedSets(){let out=[];for(let s=1;s<=18;s++){let list=ITEMS.filter(i=>i.set===s);if(list.length&&list.every(i=>+state.inventory[i.id]>0))out.push(s);}return out;}
function showSetComplete(setNo){let list=ITEMS.filter(i=>i.set===setNo);if(!list.length)return;$('#setCompleteTitle').textContent='สะสมครบ Set '+setNo+'!';$('#setCompleteText').textContent=list[0].setName+' ครบ '+list.length+' ชนิด • ได้ตรา Collection Master';$('#setComplete').classList.add('show');}
$('#closeSetComplete').onclick=()=>$('#setComplete').classList.remove('show');
async function collect(){
  let sp=state.activeSpawn,it=sp&&sp.item;if(!sp||!it)return;
  if(!scheduleActive(sp))return toast('ช่วงเวลาการเกิดสิ้นสุดแล้ว');
  let beforeSets=new Set(completedSets()),oldInv=state.inventory[it.id]||0,oldCol=state.collected[sp.id]||0,oldToday=state.todayCount,oldStats={...state.todayStats};
  state.inventory[it.id]=oldInv+1;state.collected[sp.id]=Date.now();state.todayCount=oldToday+1;state.todayStats[it.rarity]=(+state.todayStats[it.rarity]||0)+1;state.lastCollectRarity=it.rarity;save();
  document.body.insertAdjacentHTML('beforeend','<div class="successFx"></div>');setTimeout(()=>$('.successFx')?.remove(),800);toast('✨ ได้รับ '+it.name+' ×1');
  if(state.cloud&&!state.demo){
    try{let d=await api('collect',{studentCode:state.studentCode,spawnId:sp.id,itemId:it.id,question:state.question?.q||''});if(d.inventory)state.inventory=d.inventory;if(d.collected)state.collected=d.collected;if(Number.isFinite(+d.todayCount))state.todayCount=+d.todayCount;if(d.todayStats)state.todayStats=Object.assign({common:0,rare:0,epic:0,legendary:0},d.todayStats);if(Array.isArray(d.leaderboard))state.leaderboard=d.leaderboard;save();}
    catch(e){state.inventory[it.id]=oldInv;state.collected[sp.id]=oldCol;if(!oldCol)delete state.collected[sp.id];state.todayCount=oldToday;state.todayStats=oldStats;save();toast('ซิงก์ไม่สำเร็จ • ยังไม่นับชิ้นนี้ในระบบกลาง');setTimeout(closeAR,650);return;}
  }
  let afterSets=completedSets().filter(s=>!beforeSets.has(s));if(afterSets.length)setTimeout(()=>showSetComplete(afterSets[0]),850);
  setTimeout(closeAR,650);
}

function panel(tab){
  show('panel');let title=$('#panelTitle'),body=$('#panelBody');body.innerHTML='';
  if(tab==='bag'){
    title.textContent='🎒 กระเป๋า 4 มิติ';body.innerHTML=`<div class="panelStats"><b>${sumBag()}</b><span>ชิ้นทั้งหมด</span><b>${uniqueBag()}</b><span>ชนิดที่พบ</span></div><button id="openMix" class="mixOpenBtn">🧪 ห้องผสมมิติ • Mix / Craft</button><h3 class="sectionTitle">ของสะสมทั้งหมด</h3><div class="panelGrid"></div>`;
    let grid=body.querySelector('.panelGrid');ITEMS.filter(it=>state.inventory[it.id]).sort((a,b)=>a.set-b.set||rarityRank[b.rarity]-rarityRank[a.rarity]).forEach(it=>{let d=document.createElement('div');d.className='itemCard';d.innerHTML=`<span class="countBadge">×${state.inventory[it.id]}</span><img src="${it.img}" alt="${esc(it.name)}"><b>${esc(it.name)}</b><span class="rarityChip ${it.rarity}">${rarityLabel[it.rarity]}</span><small>Set ${it.set} • ${esc(it.setName)}</small>`;grid.appendChild(d);});if(!grid.children.length)grid.innerHTML='<p>ยังไม่มีของสะสม ออกเดินหาได้เลย!</p>'; $('#openMix').onclick=()=>panel('mix');
  }
  if(tab==='mix'){
    title.textContent='🧪 ห้องผสมมิติ';
    const craftedTotal=Object.values(state.crafted||{}).reduce((a,b)=>a+(+b||0),0);
    const activeList=Object.entries(state.activeEffects||{}).filter(([,ts])=>+ts>Date.now());
    body.innerHTML=`<div class="mixHero"><b>Mix • Craft • ใช้พลัง • แลกของ</b><small>ของที่คราฟต์ได้ใช้ช่วยการล่าต่อได้จริง</small><div class="mixStats"><span>🧪 ของคราฟต์ ${craftedTotal}</span><span>🪙 เหรียญมิติ ${state.tokens||0}</span></div></div>
    ${activeList.length?`<div class="activeEffects"><b>✨ พลังที่กำลังทำงาน</b>${activeList.map(([k,ts])=>`<span>${esc(k)} • ${remainingText(ts)}</span>`).join('')}</div>`:''}
    <div class="mixTabs"><button id="mixRecipesTab" class="active">สูตรผสม</button><button id="mixNpcTab">NPC แลกของ</button><button id="mixPortalTab">ประตูมิติ</button></div>
    <div id="mixRecipesPane"><h3 class="sectionTitle">สูตรผสม</h3><div id="recipeGrid" class="recipeGrid"></div><h3 class="sectionTitle">ของผสมที่สร้างแล้ว</h3><div id="craftedGrid" class="craftedGrid"></div></div>
    <div id="mixNpcPane" class="hidden"><div class="npcHero"><span>🧙‍♂️</span><div><b>พ่อค้าแห่งมิติ</b><small>เอาของซ้ำ 3 ชิ้นมาแลกเป็นเหรียญมิติ • ถ้าใช้แกนจักรกลโบราณอยู่จะได้ ×2</small></div></div><div id="npcExchangeList"></div></div>
    <div id="mixPortalPane" class="hidden"><div class="portalHero"><div class="portalRing">🌀</div><b>ประตูมิติ</b><small>ใช้กุญแจพอร์ทัล 1 ดอก เพื่อสุ่มรับไอเทม Rare / Epic / Legendary</small><div id="portalKeyCount"></div><button id="openPortalBtn">🗝️ เปิดประตูมิติ</button></div></div>`;
    const rg=$('#recipeGrid');
    CRAFT_RECIPES.forEach(rc=>{
      const owned=+state.crafted[rc.id]||0;
      const can=Object.entries(rc.ingredients).every(([id,n])=>(+state.inventory[id]||0)>=n);
      const discovered=!rc.secret||owned>0||can;
      let d=document.createElement('div');d.className='recipeCard '+(can?'ready':'locked')+(rc.secret?' secret':'');
      if(!discovered){
        d.innerHTML=`<div class="recipeIcon">❓</div><div class="recipeMeta"><b>สูตรลับที่ยังไม่ค้นพบ</b><small>ลองสะสมวัตถุดิบจากต่างมิติให้มากขึ้น</small></div><button disabled>???</button>`;
      }else{
        d.innerHTML=`<div class="recipeIcon">${rc.icon}</div><div class="recipeMeta"><b>${esc(rc.name)}${rc.secret?' • สูตรลับ':''}</b><small>${rc.secret?'✨ ค้นพบสูตรลับ! • ':''}${esc(rc.desc)}<br>${esc(rc.effectText||'')}</small><div class="ingredients">${Object.entries(rc.ingredients).map(([id,n])=>{let it=itemById(id);return `<span class="${(+state.inventory[id]||0)>=n?'have':'need'}">${esc(it?.name||id)} ${+state.inventory[id]||0}/${n}</span>`}).join('')}</div></div><button ${can?'':'disabled'} data-craft="${rc.id}">${can?'ผสม':'ของไม่พอ'}</button>`;
      }
      rg.appendChild(d);
    });
    rg.querySelectorAll('[data-craft]').forEach(b=>b.onclick=async()=>{let rc=recipeById(b.dataset.craft);if(!rc)return;try{if(state.cloud&&!state.demo){let d=await api('craft',{studentCode:state.studentCode,recipeId:rc.id});if(d.inventory)state.inventory=d.inventory;if(d.crafted)state.crafted=d.crafted;if(Number.isFinite(+d.tokens))state.tokens=+d.tokens;if(d.activeEffects)state.activeEffects=d.activeEffects;}else{for(let [id,n] of Object.entries(rc.ingredients))state.inventory[id]-=n;state.crafted[rc.id]=(+state.crafted[rc.id]||0)+1;}save();toast('🧪 สำเร็จ! ได้ '+rc.name);panel('mix');}catch(e){toast('ผสมไม่สำเร็จ • '+e.message);}});
    const cg=$('#craftedGrid');let made=CRAFT_RECIPES.filter(rc=>(+state.crafted[rc.id]||0)>0);
    cg.innerHTML=made.length?made.map(rc=>`<div class="craftedCard"><span>${rc.icon}</span><div><b>${esc(rc.name)}</b><small>${esc(rc.effectText||rc.desc)}</small></div><strong>×${state.crafted[rc.id]}</strong>${rc.effect==='portal'?'<button data-portal-go>เปิดประตู</button>':`<button data-use-craft="${rc.id}">ใช้</button>`}</div>`).join(''):'<div class="emptyState">ยังไม่มีของผสม • ออกไปล่าวัตถุดิบแล้วกลับมาสร้างได้เลย</div>';
    cg.querySelectorAll('[data-use-craft]').forEach(b=>b.onclick=async()=>{let rc=recipeById(b.dataset.useCraft);if(!rc)return;try{if(state.cloud&&!state.demo){let d=await api('useCraft',{studentCode:state.studentCode,recipeId:rc.id});if(d.crafted)state.crafted=d.crafted;if(Number.isFinite(+d.tokens))state.tokens=+d.tokens;if(d.activeEffects)state.activeEffects=d.activeEffects;}else{state.crafted[rc.id]=Math.max(0,(+state.crafted[rc.id]||0)-1);state.activeEffects[rc.effect]=Date.now()+(rc.durationMin||30)*60000;}save();toast('✨ ใช้ '+rc.name+' แล้ว');panel('mix');}catch(e){toast('ใช้ไอเทมไม่สำเร็จ • '+e.message);}});
    const goNpc=()=>{$('#mixRecipesPane').classList.add('hidden');$('#mixPortalPane').classList.add('hidden');$('#mixNpcPane').classList.remove('hidden');$('#mixRecipesTab').classList.remove('active');$('#mixPortalTab').classList.remove('active');$('#mixNpcTab').classList.add('active');};
    const goPortal=()=>{$('#mixRecipesPane').classList.add('hidden');$('#mixNpcPane').classList.add('hidden');$('#mixPortalPane').classList.remove('hidden');$('#mixRecipesTab').classList.remove('active');$('#mixNpcTab').classList.remove('active');$('#mixPortalTab').classList.add('active');};
    $('#mixRecipesTab').onclick=()=>panel('mix');$('#mixNpcTab').onclick=goNpc;$('#mixPortalTab').onclick=goPortal;cg.querySelectorAll('[data-portal-go]').forEach(b=>b.onclick=goPortal);
    const ex=$('#npcExchangeList'),exchangeables=ITEMS.filter(it=>(+state.inventory[it.id]||0)>=3).sort((a,b)=>(+state.inventory[b.id]||0)-(+state.inventory[a.id]||0));
    ex.innerHTML=exchangeables.length?exchangeables.map(it=>`<div class="exchangeRow"><img src="${it.img}"><div><b>${esc(it.name)}</b><small>มี ${state.inventory[it.id]} ชิ้น • ใช้ 3 ชิ้น</small></div><button data-exchange="${it.id}">แลก</button></div>`).join(''):'<div class="emptyState">ยังไม่มีของซ้ำครบ 3 ชิ้น</div>';
    ex.querySelectorAll('[data-exchange]').forEach(b=>b.onclick=async()=>{let it=itemById(b.dataset.exchange);if(!it)return;try{if(state.cloud&&!state.demo){let d=await api('exchange',{studentCode:state.studentCode,itemId:it.id});if(d.inventory)state.inventory=d.inventory;if(Number.isFinite(+d.tokens))state.tokens=+d.tokens;if(d.activeEffects)state.activeEffects=d.activeEffects;}else{state.inventory[it.id]-=3;state.tokens=(+state.tokens||0)+(effectActive('trader_bonus')?2:1);}save();toast('🪙 แลกสำเร็จ!');panel('mix');setTimeout(()=>{$('#mixNpcTab')?.click();},0);}catch(e){toast('แลกไม่สำเร็จ • '+e.message);}});
    $('#portalKeyCount').textContent='กุญแจพอร์ทัลที่มี ×'+(+state.crafted.mix_portal_key||0);
    $('#openPortalBtn').disabled=(+state.crafted.mix_portal_key||0)<1;
    $('#openPortalBtn').onclick=async()=>{try{if(state.cloud&&!state.demo){let d=await api('openPortal',{studentCode:state.studentCode});if(d.inventory)state.inventory=d.inventory;if(d.crafted)state.crafted=d.crafted;if(Number.isFinite(+d.tokens))state.tokens=+d.tokens;if(d.activeEffects)state.activeEffects=d.activeEffects;toast('🌀 ประตูเปิด! ได้ '+(d.rewardName||'ไอเทมพิเศษ'));}else{throw new Error('ประตูมิติต้องเชื่อมระบบกลาง');}save();panel('mix');setTimeout(()=>{$('#mixPortalTab')?.click();},0);}catch(e){toast('เปิดประตูไม่สำเร็จ • '+e.message);}};
  }
  if(tab==='dex'){
    title.textContent='📚 Dimension Dex';let sets=[...new Set(ITEMS.map(x=>x.set))];
    sets.forEach(s=>{let list=ITEMS.filter(x=>x.set===s),got=list.filter(x=>state.inventory[x.id]).length,complete=got===list.length,d=document.createElement('div');d.className='dexSet '+(complete?'complete':'');d.innerHTML=`<div class="dexHead"><b>Set ${s} • ${esc(list[0].setName)}</b><span>${got}/${list.length}</span></div>${complete?'<div class="dexComplete">🏆 COLLECTION COMPLETE</div>':''}<div class="dexBar"><i style="width:${got/list.length*100}%"></i></div>`;body.appendChild(d);});
  }
  if(tab==='rank'){title.textContent='🏆 ตารางคะแนน';renderRank(body);}
  if(tab==='settings'){title.textContent='⚙️ ตั้งค่า';renderSettings(body);}
}
$$('[data-tab]').forEach(b=>b.onclick=()=>{if(b.dataset.tab==='radar'){show('main');render();}else panel(b.dataset.tab);});$('#backPanel').onclick=()=>{show('main');render();};
async function renderRank(body){
  body.innerHTML='<div class="rankIntro">จัดอันดับจากจำนวนของที่เก็บสะสมทั้งหมด</div><div id="rankList" class="rankList"><div class="loading">กำลังโหลด...</div></div>';
  if(state.cloud){try{let d=await api('leaderboard',{studentCode:state.studentCode});state.leaderboard=d.leaderboard||[];save();}catch(e){}}
  let list=state.leaderboard||[];if(!list.length&&state.student)list=[{code:state.studentCode,name:state.student,grade:state.grade,total:sumBag(),unique:uniqueBag()}];
  $('#rankList').innerHTML=list.slice(0,30).map((x,i)=>`<div class="rankRow ${x.code===state.studentCode?'meRow':''}"><div class="rankNo">${i<3?['🥇','🥈','🥉'][i]:i+1}</div><div><b>${esc(x.name)}</b><small>ป.${esc(x.grade)} • พบ ${esc(x.unique||0)} ชนิด</small></div><strong>${esc(x.total||0)}</strong></div>`).join('')||'<div class="emptyState">ยังไม่มีข้อมูลอันดับ</div>';
}
function renderSettings(body){
  body.innerHTML=`<div class="settings"><div class="block"><b>${state.teacherSession?'บัญชีโหมดครู':'บัญชีผู้เล่น'}</b><p>${esc(state.studentCode)} • ${esc(state.student)}${state.teacherSession?'':' • ป.'+state.grade}</p><div class="statusLine"><span class="syncDot ${state.cloud?'ok':'local'}"></span>${state.cloud?'เชื่อมข้อมูล Google Sheet':'ใช้ข้อมูลเฉพาะเครื่อง'}</div>${state.cloud?'<button id="syncNow">☁️ ซิงก์เดี๋ยวนี้</button>':''}<div class="dailyStats"><div><b>${state.todayCount}</b>วันนี้</div><div><b>${todayRarePlus()}</b>Rare+</div><div><b>${Math.round(state.walk.meters||0)}</b>เมตร</div><div><b>${completedSets().length}</b>ครบเซ็ต</div></div></div><div class="block"><b>โหมดทดสอบ</b><p>ใช้ปุ่มนี้บนคอมเพื่อจำลองการเดินเข้าหาจุดใกล้ที่สุด</p><button id="walkDemo">🚶 จำลองเดิน 10 เมตร</button></div><div class="block"><b>โหมดครู — ตั้งจุดเกิดของ</b><p>กรอกรหัสครูเพื่อจัดการจุดเกิด ปล่อยหลายชิ้น และกำหนดขอบเขต</p><input id="teachCode" type="password" inputmode="numeric" placeholder="รหัสครู"><button id="teacherOpen">เปิดโหมดครู</button></div><div class="block"><b>ข้อมูลในเครื่อง</b><button id="resetCollect">ล้างแคชของสะสมในเครื่อง</button><button id="resetAll">ออกจากระบบ / รีเซ็ตเครื่องนี้</button></div></div>`;
  $('#walkDemo').onclick=moveDemo;if($('#syncNow'))$('#syncNow').onclick=()=>cloudBootstrap();$('#teacherOpen').onclick=()=>teacherLogin(body);
  $('#resetCollect').onclick=()=>{state.inventory={};state.collected={};state.todayCount=0;state.todayStats={common:0,rare:0,epic:0,legendary:0};save();toast('ล้างข้อมูลในเครื่องแล้ว • ซิงก์ใหม่เพื่อดึงข้อมูลกลาง');};
  $('#resetAll').onclick=()=>{localStorage.removeItem(STORE);localStorage.removeItem(OLD_STORE);location.reload();};
}

function randomBetween(min,max){return min+Math.random()*(max-min);}
function shuffleArray(arr){let a=[...arr];for(let i=a.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
function pointFromDistance(center,distanceMeters,angle){let dLat=(distanceMeters*Math.cos(angle))/111111,dLng=(distanceMeters*Math.sin(angle))/(111111*Math.cos(rad(center.lat)));return {lat:center.lat+dLat,lng:center.lng+dLng};}
function isInsideBoundary(point,boundary){return !boundary||hav({lat:+boundary.lat,lng:+boundary.lng},point)<=+boundary.radius;}
function getDistanceBand(maxRadius,band){let safeMin=Math.min(Math.max(4,maxRadius*.12),maxRadius*.28);if(band==='near')return {min:safeMin,max:Math.max(safeMin+1,maxRadius*.38)};if(band==='mid')return {min:Math.max(safeMin,maxRadius*.38),max:Math.max(safeMin+2,maxRadius*.70)};return {min:Math.max(safeMin,maxRadius*.70),max:maxRadius};}
function randomDistanceInBand(maxRadius,band){let x=getDistanceBand(maxRadius,band),min=Math.max(0,x.min),max=Math.max(min+.5,x.max);return Math.sqrt(randomBetween(min*min,max*max));}
function pointHasEnoughGap(point,points,minGap){return points.every(p=>hav(point,p)>=minGap);}
function farEnoughFromExisting(point,existingSpawns,minGap){return !Array.isArray(existingSpawns)||existingSpawns.every(s=>!Number.isFinite(+s.lat)||!Number.isFinite(+s.lng)||hav(point,{lat:+s.lat,lng:+s.lng})>=minGap);}
function createBandPattern(count){let bands=[],near=Math.round(count*.30),far=Math.round(count*.30),mid=Math.max(0,count-near-far);for(let i=0;i<near;i++)bands.push('near');for(let i=0;i<mid;i++)bands.push('mid');for(let i=0;i<far;i++)bands.push('far');return shuffleArray(bands);}
function generateSpreadPoints({center,count,maxRadius,minGap,boundary=null,existingSpawns=[]}){
  let points=[],bands=createBandPattern(count),maxAttempts=80;
  for(let i=0;i<bands.length;i++){
    let band=bands[i],placed=false,currentGap=minGap;
    for(let attempt=0;attempt<maxAttempts;attempt++){
      if(attempt===35)currentGap=Math.max(3,minGap*.85);
      if(attempt===60)currentGap=Math.max(2.5,minGap*.70);
      let distance=randomDistanceInBand(maxRadius,band),angle=Math.random()*Math.PI*2,candidate=pointFromDistance(center,distance,angle);
      if(!isInsideBoundary(candidate,boundary))continue;
      if(!pointHasEnoughGap(candidate,points,currentGap))continue;
      if(!farEnoughFromExisting(candidate,existingSpawns,currentGap))continue;
      points.push({...candidate,band,distance});placed=true;break;
    }
    if(!placed)console.warn('วาง Spawn ไม่ได้โดยไม่ให้กระจุก',i+1,band);
  }
  return points;
}
async function teacherLogin(body,directCode){let code=(directCode||$('#teachCode')?.value||'').trim();if(!code)return toast('กรอกรหัสครู');if(!state.cloud){if(code===state.teacherCode)return teacherPanel(body,code);return toast('รหัสครูไม่ถูกต้อง');}try{await api('teacherOverview',{teacherCode:code});teacherPanel(body,code);}catch(e){toast('รหัสครูไม่ถูกต้อง หรือเชื่อมต่อไม่ได้');}}
async function teacherPanel(body,teacherCode){
  const boundary=state.boundary;
  body.innerHTML=`<div class="settings"><div id="teacherStats" class="teacherStats"></div><div class="block"><b>🎛️ ศูนย์ควบคุมครู</b><p class="teacherPanelTitle">ปล่อยวัตถุแบบสุ่มกระจายใกล้–กลาง–ไกล โดยเว้นระยะห่างและไม่กองรวมเป็นกระจุก</p><div class="teacherZoneBadge">📍 ${state.pos?'ตำแหน่ง GPS พร้อมใช้งาน':'กำลังรอ GPS'}</div><div class="miniGrid"><label>ชื่อจุด / ชื่อโซน<input id="spawnLabel" maxlength="50" placeholder="เช่น สวนหน้าอาคาร"></label><label>ไอเทมที่ปล่อย<select id="teacherItem"></select></label></div><div class="miniGrid3"><label>จำนวนชิ้น<input id="spawnCount" type="number" min="1" max="50" value="10"></label><label>รัศมีกระจาย (ม.)<input id="scatterRadius" type="number" min="8" max="150" value="30"></label><label>ระยะห่างขั้นต่ำ (ม.)<input id="minGap" type="number" min="2" max="30" value="7"></label></div><div class="miniGrid"><label>รัศมีที่นักเรียนเก็บได้ (ม.)<input id="radius" type="number" min="5" max="50" value="18"></label><label>เกิดใหม่ทุก (ชม.)<input id="cooldownHours" type="number" min="1" max="168" value="24"></label></div><div class="teacherSchedule"><label>เริ่มเกิด<input id="startHour" type="number" min="0" max="23" value="0"></label><label>หยุดเกิด<input id="endHour" type="number" min="1" max="24" value="24"></label><label>วันที่เกิด<select id="dayMode"><option value="all">ทุกวัน</option><option value="weekdays">จันทร์–ศุกร์</option><option value="weekend">เสาร์–อาทิตย์</option></select></label></div><div class="miniGrid"><label>รัศมีขอบเขตพื้นที่ (ม.)<input id="boundaryRadius" type="number" min="10" max="500" value="${boundary?.radius||60}"></label><label>รูปแบบการกระจาย<select id="spreadMode"><option value="balanced">ใกล้ + กลาง + ไกล</option></select></label></div><div class="helperText">สัดส่วนประมาณ 30% ใกล้จุดกลาง • 40% ระยะกลาง • 30% รอบนอก และจะพยายามเว้นระยะจากทั้งวัตถุชุดใหม่และ Spawn เดิม หากพื้นที่ไม่พอ ระบบจะลดจำนวนแทนการยัดให้เป็นกระจุก</div><div class="spawnActions"><button id="addHere">＋ ปล่อย 1 ชิ้นตรงนี้</button><button id="addBatch">✨ กระจายหลายชิ้น</button><button id="saveBoundary">🧭 กำหนดขอบเขตตรงนี้</button><button id="deleteToday" class="dangerAction">🗑️ ลบของที่ปล่อยวันนี้ทั้งหมด</button></div></div><div class="block"><b>🧭 ขอบเขตพื้นที่เล่น</b><div id="boundaryInfo" class="emptyState"></div></div><div class="block"><div class="spawnListHead"><b>📍 จุดที่ตั้งไว้</b><div><button id="selectAllSpawns">เลือกทั้งหมด</button><button id="clearSpawnSelection">ยกเลิกเลือก</button><button id="deleteSelectedSpawns" class="dangerAction">🗑️ ลบที่เลือก</button></div></div><div id="spawnList"></div></div>${!state.cloud?'<div class="block"><b>ย้ายข้อมูลจุดเกิด</b><textarea id="cfg" rows="5"></textarea><button id="exportCfg">ส่งออก JSON</button><button id="importCfg">นำเข้า JSON</button></div><div class="block"><b>เปลี่ยนรหัสครูในเครื่อง</b><input id="newCode" inputmode="numeric" value="'+esc(state.teacherCode)+'"><button id="saveCode">บันทึกรหัส</button></div>':''}</div>`;
  let sel=$('#teacherItem');ITEMS.slice().sort((a,b)=>rarityRank[a.rarity]-rarityRank[b.rarity]||a.set-b.set).forEach(i=>{let o=document.createElement('option');o.value=i.id;o.textContent=`[${rarityLabel[i.rarity]}] Set ${i.set} • ${i.name}`;sel.appendChild(o);});
  function drawBoundary(){let b=state.boundary;if(!b){$('#boundaryInfo').innerHTML='<div class="emptyState">ยังไม่ได้กำหนดขอบเขต • การปล่อยหลายชิ้นจะใช้รัศมีกระจายรอบตำแหน่งครู</div>';return;}$('#boundaryInfo').innerHTML=`<div><b>✅ มีขอบเขตพื้นที่แล้ว</b><small class="subtle">ศูนย์กลาง ${(+b.lat).toFixed(6)}, ${(+b.lng).toFixed(6)} • รัศมี ${Math.round(+b.radius)} เมตร</small></div>`;}
  let draw=()=>{let entries=state.spawns.map((s,i)=>{let it=itemById(s.itemId);return `<div class="spawnRow"><label class="spawnCheck"><input type="checkbox" data-spawn-check="${esc(s.id)}"><span></span></label><div><b>${i+1}. ${esc(it?.name||s.itemId)}</b><span class="rarityChip ${it?.rarity||'common'}">${rarityLabel[it?.rarity||'common']}</span><small>${esc(s.label||'ไม่ระบุชื่อจุด')} • ${s.radius||18} ม. • ${Math.round((s.cooldown||86400000)/3600000)} ชม. <span class="scheduleTag">${scheduleText(s)}</span></small></div><button data-del="${i}">ลบ</button></div>`;}).join('');$('#spawnList').innerHTML=entries||'<div class="emptyState">ยังไม่มีจุดเกิด</div>';$$('[data-del]').forEach(b=>b.onclick=async()=>{let s=state.spawns[+b.dataset.del];if(state.cloud){try{await api('deleteSpawn',{teacherCode,spawnId:s.id});await refreshTeacher(teacherCode,draw);}catch(e){toast('ลบไม่สำเร็จ');}}else{state.spawns.splice(+b.dataset.del,1);save();draw();}});drawBoundary();};draw();
  async function refreshTeacher(code,after){if(!state.cloud){after&&after();return;}try{let d=await api('teacherOverview',{teacherCode:code});state.spawns=d.spawns||state.spawns;let st=d.stats||{};$('#teacherStats').innerHTML=`<div><b>${st.students||0}</b><span>นักเรียน</span></div><div><b>${st.collections||0}</b><span>เก็บทั้งหมด</span></div><div><b>${st.today||0}</b><span>วันนี้</span></div><div><b>${state.spawns.length}</b><span>จุดเกิด</span></div>`;save();after&&after();}catch(e){$('#teacherStats').innerHTML='<div class="emptyState">โหลดสรุปครูไม่สำเร็จ</div>';}}
  await refreshTeacher(teacherCode,draw);
  async function saveSpawnOne(spawn){if(state.cloud)await api('saveSpawn',{teacherCode,spawn});else state.spawns.push(spawn);}
  function readBase(){let start=Math.max(0,Math.min(23,+$('#startHour').value||0)),end=Math.max(1,Math.min(24,+$('#endHour').value||24));return {itemId:sel.value,radius:+$('#radius').value||18,cooldown:(+$('#cooldownHours').value||24)*3600000,label:$('#spawnLabel').value.trim(),active:true,startHour:start,endHour:end,dayMode:$('#dayMode').value};}
  $('#addHere').onclick=async()=>{if(!state.pos)return toast('ยังไม่มีพิกัด GPS');let now=Date.now(),spawn={id:'p'+now,createdAt:new Date(now).toISOString(),lat:state.pos.lat,lng:state.pos.lng,...readBase()};try{await saveSpawnOne(spawn);toast('บันทึกจุดเกิดแล้ว');if(state.cloud)await refreshTeacher(teacherCode,draw);else{save();draw();}}catch(e){toast('บันทึกไม่สำเร็จ • '+e.message);}};
  $('#addBatch').onclick=async()=>{
    if(!state.pos)return toast('ยังไม่มีพิกัด GPS');
    let requestedCount=Math.max(1,Math.min(50,+$('#spawnCount').value||10)),scatterRadius=Math.max(8,Math.min(150,+$('#scatterRadius').value||30)),minGap=Math.max(2,Math.min(30,+$('#minGap').value||7)),base=readBase(),labelPrefix=$('#spawnLabel').value.trim()||'โซนภารกิจ';
    let points=generateSpreadPoints({center:{lat:state.pos.lat,lng:state.pos.lng},count:requestedCount,maxRadius:scatterRadius,minGap,boundary:state.boundary||null,existingSpawns:state.spawns});
    if(!points.length)return toast('พื้นที่แคบเกินไป ไม่สามารถกระจายวัตถุได้');
    let created=0;
    try{
      for(let i=0;i<points.length;i++){
        let p=points[i],bandThai=p.band==='near'?'ใกล้':p.band==='mid'?'กลาง':'ไกล',now=Date.now(),spawn={id:'p'+now+'_'+i+'_'+Math.random().toString(36).slice(2,6),createdAt:new Date(now).toISOString(),lat:p.lat,lng:p.lng,...base,label:labelPrefix+' #'+(i+1)+' • '+bandThai};
        await saveSpawnOne(spawn);created++;
        if(state.cloud&&created%5===0)await new Promise(resolve=>setTimeout(resolve,250));
      }
      toast(created<requestedCount?`กระจายได้ ${created}/${requestedCount} ชิ้น • พื้นที่ไม่พอสำหรับวางทั้งหมดโดยไม่ให้กระจุก`:`✨ กระจายวัตถุ ${created} ชิ้นเรียบร้อย`);
      if(state.cloud)await refreshTeacher(teacherCode,draw);else{save();draw();}
    }catch(e){toast('ปล่อยหลายชิ้นไม่สำเร็จ • '+e.message);}
  };
  function spawnCreatedTime(spawn){
    if(spawn?.createdAt){let t=new Date(spawn.createdAt).getTime();if(Number.isFinite(t))return t;}
    let m=String(spawn?.id||'').match(/^p(\d{13})/);return m?Number(m[1]):NaN;
  }
  function isTodaySpawn(spawn){
    let t=spawnCreatedTime(spawn);if(!Number.isFinite(t))return false;
    let d=new Date(t),n=new Date();return d.getFullYear()===n.getFullYear()&&d.getMonth()===n.getMonth()&&d.getDate()===n.getDate();
  }
  $('#selectAllSpawns').onclick=()=>$$('[data-spawn-check]').forEach(x=>x.checked=true);
  $('#clearSpawnSelection').onclick=()=>$$('[data-spawn-check]').forEach(x=>x.checked=false);
  $('#deleteSelectedSpawns').onclick=async()=>{let ids=$$('[data-spawn-check]:checked').map(x=>x.dataset.spawnCheck);if(!ids.length)return toast('ยังไม่ได้เลือกรายการที่จะลบ');if(!confirm(`ต้องการลบ ${ids.length} รายการที่เลือกหรือไม่?`))return;try{if(state.cloud){for(let i=0;i<ids.length;i++){await api('deleteSpawn',{teacherCode,spawnId:ids[i]});if(i&&i%5===0)await new Promise(r=>setTimeout(r,180));}await refreshTeacher(teacherCode,draw);}else{let set=new Set(ids);state.spawns=state.spawns.filter(x=>!set.has(x.id));save();draw();}toast(`🗑️ ลบ ${ids.length} รายการแล้ว`);}catch(e){toast('ลบรายการที่เลือกไม่สำเร็จ • '+e.message);}};
  $('#deleteToday').onclick=async()=>{
    let today=state.spawns.filter(isTodaySpawn);
    if(!today.length)return toast('วันนี้ยังไม่มีจุดเกิดที่ต้องลบ');
    if(!confirm(`ต้องการลบจุดเกิดที่สร้างวันนี้ทั้งหมด ${today.length} จุดหรือไม่?`))return;
    try{
      if(state.cloud){
        let done=0;
        for(let sp of today){await api('deleteSpawn',{teacherCode,spawnId:sp.id});done++;if(done%5===0)await new Promise(r=>setTimeout(r,200));}
        await refreshTeacher(teacherCode,draw);
      }else{
        let ids=new Set(today.map(sp=>sp.id));state.spawns=state.spawns.filter(sp=>!ids.has(sp.id));save();draw();
      }
      toast(`🗑️ ลบจุดที่ปล่อยวันนี้ ${today.length} จุดแล้ว`);
    }catch(e){toast('ลบรายการวันนี้ไม่สำเร็จ • '+e.message);}
  };
  $('#saveBoundary').onclick=()=>{if(!state.pos)return toast('ยังไม่มีพิกัด GPS');let boundaryRadius=Math.max(10,Math.min(500,+$('#boundaryRadius').value||60));state.boundary={lat:state.pos.lat,lng:state.pos.lng,radius:boundaryRadius};save();drawBoundary();toast(`บันทึกขอบเขตรัศมี ${boundaryRadius} เมตรแล้ว`);};
  if($('#exportCfg'))$('#exportCfg').onclick=()=>{$('#cfg').value=JSON.stringify(state.spawns,null,2);};
  if($('#importCfg'))$('#importCfg').onclick=()=>{try{let x=JSON.parse($('#cfg').value);if(!Array.isArray(x))throw 0;state.spawns=x;save();draw();toast('นำเข้าจุดเกิดแล้ว');}catch(e){toast('รูปแบบ JSON ไม่ถูกต้อง');}};
  if($('#saveCode'))$('#saveCode').onclick=()=>{let c=$('#newCode').value.trim();if(c.length<4)return toast('รหัสควรมีอย่างน้อย 4 ตัว');state.teacherCode=c;save();toast('เปลี่ยนรหัสครูแล้ว');};
}


setInterval(()=>{if($('#main').classList.contains('active'))render();},4000);
setInterval(()=>{if(state.cloud&&state.studentCode&&!state.demo&&!state.syncing)cloudBootstrap(true);},+CFG.CLOUD_SYNC_INTERVAL_MS||60000);
if('serviceWorker'in navigator&&(window.isSecureContext||location.hostname==='localhost'||location.hostname==='127.0.0.1'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();
