# AR Dimension Hunt v0.4 — Online Ready

เวอร์ชันนี้เตรียมสำหรับ HTTPS hosting (แนะนำ Vercel) และเชื่อม Google Apps Script URL เดิม

## จุดสำคัญ
- GPS และกล้องต้องใช้งานบน HTTPS
- API ใช้ POST ก่อน และมี JSONP fallback สำหรับกรณี CORS ของ Google Apps Script
- ต้องอัปเดต Code.gs เป็น v0.4 แล้ว Deploy เป็น New version
- หลัง deploy เว็บเกมสามารถอยู่คนละโดเมนกับ Apps Script ได้

## Vercel
อัปโหลดโฟลเดอร์นี้ทั้งโฟลเดอร์ โดยให้ index.html อยู่ที่ root ของ deployment
