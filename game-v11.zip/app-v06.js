(()=>{
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const CFG=window.GAME_CONFIG||{};
const STORE='ar_dimension_hunt_v3';
const OLD_STORE='ar_dimension_hunt_v2';
const rarityLabel={common:'ทั่วไป',rare:'หายาก',epic:'มหากาพย์',legendary:'ตำนาน'};
const rarityRank={common:1,rare:2,epic:3,legendary:4};
const apiUrl=String(CFG.API_URL||'').trim();
const state={
  student:null,studentCode:'',grade:4,demo:false,pos:null,acc:null,speed:0,lastPos:null,
  spawns:[],inventory:{},collected:{},todayCount:0,todayStats:{common:0,rare:0,epic:0,legendary:0},
  leaderboard:[],activeSpawn:null,question:null,answer:'',watch:null,camera:null,teacherCode:'2468',
  cloud:/^https:\/\//.test(apiUrl),syncing:false,lastSync:0,mapRange:150,view:'radar',
  walk:{date:'',meters:0},legendarySeen:{},publicConfig:{},lastCollectRarity:null
};

function todayKey(){return new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Bangkok'});}
function save(){
  localStorage.setItem(STORE,JSON.stringify({student:state.student,studentCode:state.studentCode,grade:state.grade,spawns:state.spawns,inventory:state.inventory,collected:state.collected,todayCount:state.todayCount,todayStats:state.todayStats,teacherCode:state.teacherCode,mapRange:state.mapRange,walk:state.walk,legendarySeen:state.legendarySeen}));
}
function load(){
  try{
    let raw=localStorage.getItem(STORE)||localStorage.getItem(OLD_STORE)||'{}';
    let d=JSON.parse(raw); Object.assign(state,d);
  }catch(e){}
  if(!state.todayStats)state.todayStats={common:0,rare:0,epic:0,legendary:0};
  if(!state.walk||state.walk.date!==todayKey())state.walk={date:todayKey(),meters:0};
  if(!state.legendarySeen)state.legendarySeen={};
}
load();

function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function show(id){$$('.screen').forEach(x=>x.classList.remove('active'));$('#'+id).classList.add('active');}
function toast(t){let x=$('#toast');x.textContent=t;x.classList.add('show');clearTimeout(toast._t);toast._t=setTimeout(()=>x.classList.remove('show'),2600);}
function rad(deg){return deg*Math.PI/180;}
function hav(a,b){if(!a||!b)return 99999;let R=6371000,dLat=rad(b.lat-a.lat),dLon=rad(b.lng-a.lng);let q=Math.sin(dLat/2)**2+Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLon/2)**2;return 2*R*Math.asin(Math.sqrt(q));}
function bearing(a,b){let y=Math.sin(rad(b.lng-a.lng))*Math.cos(rad(b.lat)),x=Math.cos(rad(a.lat))*Math.sin(rad(b.lat))-Math.sin(rad(a.lat))*Math.cos(rad(b.lat))*Math.cos(rad(b.lng-a.lng));return (Math.atan2(y,x)*180/Math.PI+360)%360;}
function itemById(id){return ITEMS.find(i=>i.id===id);}
function r(a,b){return Math.floor(Math.random()*(b-a+1))+a;}
function setSync(kind='local'){let d=$('#syncDot');if(!d)return;d.className='syncDot '+kind;d.title=kind==='ok'?'ซิงก์ออนไลน์แล้ว':kind==='busy'?'กำลังซิงก์':kind==='error'?'ซิงก์ไม่สำเร็จ':'ใช้ข้อมูลในเครื่อง';}
function sumBag(){return Object.values(state.inventory).reduce((a,b)=>a+(+b||0),0);}
function uniqueBag(){return Object.keys(state.inventory).filter(k=>+state.inventory[k]>0).length;}

function setPf(id,status,label){
  const el=$(id); if(!el)return; el.className='pf '+status; if(label)el.textContent=label;
}
function pingApi(){
  return new Promise((resolve,reject)=>{
    if(!apiUrl)return reject(new Error('ยังไม่ได้ตั้ง API URL'));
    const cb='__ardh_ping_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    const sc=document.createElement('script');
    const timer=setTimeout(()=>finish(new Error('timeout')),10000);
    function finish(err,data){clearTimeout(timer);try{delete window[cb]}catch(_){window[cb]=undefined;}sc.remove();err?reject(err):resolve(data);}
    window[cb]=d=>d&&d.ok?finish(null,d):finish(new Error((d&&d.error)||'API error'));
    sc.src=apiUrl+(apiUrl.includes('?')?'&':'?')+'callback='+encodeURIComponent(cb)+'&_ping='+Date.now();
    sc.async=true;sc.onerror=()=>finish(new Error('network'));document.head.appendChild(sc);
  });
}
async function runPreflight(){
  const secure=window.isSecureContext||location.hostname==='localhost'||location.hostname==='127.0.0.1';
  const gps=!!navigator.geolocation;
  const cam=!!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia);
  setPf('#pfHttps',secure?'ok':'bad',(secure?'✅':'❌')+' HTTPS');
  setPf('#pfGps',gps?'ok':'bad',(gps?'✅':'❌')+' GPS');
  setPf('#pfCamera',cam&&secure?'ok':cam?'warn':'bad',((cam&&secure)?'✅':cam?'⚠️':'❌')+' กล้อง AR');
  const hint=$('#preflightHint');
  let apiOk=false;
  setPf('#pfApi','pending','⏳ ระบบกลาง');
  try{const d=await pingApi();apiOk=!!d.ok;setPf('#pfApi','ok','✅ ระบบกลาง');}
  catch(e){setPf('#pfApi','bad','❌ ระบบกลาง');}
  const all=secure&&gps&&cam&&apiOk;
  if(hint){
    hint.className=all?'good':'bad';
    hint.textContent=all?'พร้อมใช้งานบนมือถือแล้ว • เมื่อกดเริ่ม เบราว์เซอร์จะขอสิทธิ์ตำแหน่งและกล้อง':'ยังมีบางรายการไม่พร้อม • ใช้ HTTPS บนมือถือและอนุญาตตำแหน่ง/กล้องเมื่อระบบถาม';
  }
  return {secure,gps,cam,apiOk};
}


function apiJsonp(action,payload={}){
  return new Promise((resolve,reject)=>{
    const cb='__ardh_cb_'+Date.now()+'_'+Math.random().toString(36).slice(2);
    const script=document.createElement('script');
    const timer=setTimeout(()=>finish(new Error('API timeout')),18000);
    function finish(err,data){
      clearTimeout(timer);try{delete window[cb]}catch(_){window[cb]=undefined;}script.remove();
      if(err)reject(err);else resolve(data);
    }
    window[cb]=(data)=>{if(!data||!data.ok)return finish(new Error((data&&data.error)||'API error'));finish(null,data);};
    const packed=encodeURIComponent(JSON.stringify({action,...payload}));
    script.src=apiUrl+(apiUrl.includes('?')?'&':'?')+'callback='+encodeURIComponent(cb)+'&payload='+packed+'&_t='+Date.now();
    script.async=true;script.onerror=()=>finish(new Error('เชื่อม API ไม่สำเร็จ'));
    document.head.appendChild(script);
  });
}
async function api(action,payload={}){
  if(!state.cloud)throw new Error('offline');
  state.syncing=true;setSync('busy');
  try{
    let data;
    try{
      const res=await fetch(apiUrl,{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify({action,...payload}),redirect:'follow'});
      if(!res.ok)throw new Error('HTTP '+res.status);
      data=await res.json();
      if(!data.ok)throw new Error(data.error||'API error');
    }catch(fetchErr){
      // Google Apps Script อาจถูกเบราว์เซอร์บล็อก CORS เมื่อเกมอยู่คนละโดเมน
      // ใช้ JSONP fallback เพื่อให้ Vercel/GitHub Pages/เว็บโรงเรียนใช้งานได้จริง
      data=await apiJsonp(action,payload);
    }
    state.lastSync=Date.now();setSync('ok');return data;
  }catch(e){setSync('error');throw e;}finally{state.syncing=false;}
}

function weightedItem(){
  let n=Math.random(),rar=n<.72?'common':n<.90?'rare':n<.98?'epic':'legendary';
  let pool=ITEMS.filter(x=>x.rarity===rar);return pool[Math.floor(Math.random()*pool.length)]||ITEMS[0];
}
function defaultSpawns(center){
  let pts=[],radii=[18,28,38,50,65,80,95,110],n=24;
  for(let i=0;i<n;i++){
    let ang=(i/n)*Math.PI*2+(i%3)*.22,rr=radii[i%radii.length],dLat=(rr*Math.cos(ang))/111111,dLng=(rr*Math.sin(ang))/(111111*Math.cos(rad(center.lat))),it=weightedItem();
    let schedule=it.rarity==='legendary'?{startHour:11,endHour:13,dayMode:'weekdays'}:{startHour:0,endHour:24,dayMode:'all'};
    pts.push({id:'p'+Date.now()+'_'+i,lat:center.lat+dLat,lng:center.lng+dLng,itemId:it.id,radius:18,cooldown:86400000,active:true,label:'',...schedule});
  }
  return pts;
}

function applyBootstrap(d){
  if(d.student){state.student=d.student.name||state.student;state.grade=+d.student.grade||state.grade;}
  if(Array.isArray(d.spawns))state.spawns=d.spawns;
  if(d.inventory)state.inventory=d.inventory;
  if(d.collected)state.collected=d.collected;
  if(Number.isFinite(+d.todayCount))state.todayCount=+d.todayCount;
  if(d.todayStats)state.todayStats=Object.assign({common:0,rare:0,epic:0,legendary:0},d.todayStats);
  if(Array.isArray(d.leaderboard))state.leaderboard=d.leaderboard;
  if(d.config)state.publicConfig=d.config;
  save();
}
async function cloudBootstrap(silent=false){
  if(!state.cloud||!state.studentCode)return;
  try{let d=await api('bootstrap',{studentCode:state.studentCode,name:state.student,grade:state.grade});applyBootstrap(d);if(!silent)toast('☁️ ซิงก์ข้อมูลโรงเรียนแล้ว');render();}
  catch(e){if(!silent)toast('ใช้ข้อมูลในเครื่องชั่วคราว');}
}

let loginLookupTimer=null;
function normalizeLoginCode(v){
  const s=String(v||'').trim().toUpperCase().replace(/[^0-9AB]/g,'');
  if(s==='A'||s==='B')return s;
  return s.replace(/\D/g,'').slice(0,3);
}
function validLoginCode(code){return /^[0-9]{3}$/.test(code)||/^[AB]$/.test(code);}
function showLoginLookup(student=null,msg='',type='pending'){
  const box=$('#studentLookup');if(!box)return;box.dataset.type=type;
  if(student)box.innerHTML=`<b>✅ ${esc(student.name)}</b><small>ชั้นประถมศึกษาปีที่ ${esc(student.grade)} • รหัส ${esc(student.code)}</small>`;
  else box.innerHTML=`<b>${type==='error'?'❌':'🔎'} ${esc(msg||'กรอกรหัสนักเรียน')}</b><small>${type==='error'?'ตรวจสอบรหัสที่ได้รับจากครู':'นักเรียนใช้รหัส 3 หลัก • ครูทดสอบใช้ A หรือ B'}</small>`;
}
async function lookupLoginStudent(code,announce=true){
  code=normalizeLoginCode(code);
  if(!validLoginCode(code)){if(announce)showLoginLookup(null,'กรอกรหัสให้ครบ', 'pending');return null;}
  if(!state.cloud){if(announce)showLoginLookup(null,'ยังเชื่อมระบบกลางไม่ได้','error');return null;}
  if(announce)showLoginLookup(null,'กำลังค้นหารายชื่อ...','pending');
  try{
    const d=await api('leaderboard',{});
    const list=Array.isArray(d.leaderboard)?d.leaderboard:[];
    const student=list.find(x=>String(x.code||'').toUpperCase()===code)||null;
    if(!student){if(announce)showLoginLookup(null,'ไม่พบรหัส '+code,'error');return null;}
    $('#studentName').value=student.name||'';$('#grade').value=String(student.grade||4);
    if(announce)showLoginLookup(student);
    return student;
  }catch(e){if(announce)showLoginLookup(null,'ค้นหารายชื่อไม่สำเร็จ','error');return null;}
}
async function start(demo=false){
  let code=normalizeLoginCode($('#studentCode').value);
  if(!demo){
    if(!validLoginCode(code))return toast('กรุณาใส่รหัสนักเรียน 3 หลัก หรือ A/B');
    const student=await lookupLoginStudent(code,true);
    if(!student)return toast('ไม่พบรหัสนักเรียนนี้');
    state.student=student.name;state.studentCode=code;state.grade=+student.grade||4;state.demo=false;
  }else{
    const name='นักสำรวจ';state.student=name;state.studentCode='DEMO-'+Math.random().toString(36).slice(2,7).toUpperCase();state.grade=+$('#grade').value||4;state.demo=true;
  }
  if(state.walk.date!==todayKey())state.walk={date:todayKey(),meters:0};
  save();$('#hello').textContent=state.student+' • ป.'+state.grade;show('main');
  if(state.cloud&&!demo)await cloudBootstrap();
  if(demo){state.pos={lat:16,lng:100,t:Date.now()};state.acc=5;if(!state.spawns.length)state.spawns=defaultSpawns(state.pos);render();}
  else startGPS();
}
$('#startBtn').onclick=()=>start(false);$('#demoBtn').onclick=()=>start(true);
if($('#studentCode'))$('#studentCode').addEventListener('input',e=>{
  const code=normalizeLoginCode(e.target.value);e.target.value=code;clearTimeout(loginLookupTimer);
  $('#studentName').value='';$('#grade').value='4';
  if(validLoginCode(code))loginLookupTimer=setTimeout(()=>lookupLoginStudent(code,true),220);else showLoginLookup(null,'กรอกรหัสให้ครบ','pending');
});
if($('#recheckBtn'))$('#recheckBtn').onclick=()=>runPreflight();
runPreflight();
if(state.studentCode){$('#studentCode').value=state.studentCode||'';if(validLoginCode(state.studentCode))lookupLoginStudent(state.studentCode,true);}
$('#modeBadge').textContent=state.cloud?'☁️ เชื่อม Google Sheet':'📱 โหมดในเครื่อง';$('#modeBadge').classList.toggle('cloud',state.cloud);setSync(state.cloud?'ok':'local');

function countWalk(prev,now,coords){
  if(!prev||state.demo)return;
  if(state.walk.date!==todayKey())state.walk={date:todayKey(),meters:0};
  let dt=(now.t-prev.t)/1000,dist=hav(prev,now),acc=coords.accuracy||99,spd=coords.speed;
  let plausible=dt>0&&dt<30&&dist>1&&dist<Math.max(35,dt*4)&&acc<=40&&(spd==null||spd<=3.5);
  if(plausible){state.walk.meters=Math.min(20000,(+state.walk.meters||0)+dist);save();}
}
function startGPS(){
  if(!navigator.geolocation){toast('อุปกรณ์นี้ไม่รองรับ GPS');return;}
  $('#statusText').textContent='กำลังขอพิกัด GPS...';
  state.watch=navigator.geolocation.watchPosition(p=>{
    let now={lat:p.coords.latitude,lng:p.coords.longitude,t:Date.now()};state.acc=Math.round(p.coords.accuracy||0);
    if(state.lastPos){let dt=(now.t-state.lastPos.t)/1000;if(dt>0)state.speed=p.coords.speed??(hav(state.lastPos,now)/dt);countWalk(state.lastPos,now,p.coords);}
    state.lastPos=now;state.pos=now;
    if(!state.spawns.length&&!state.cloud){state.spawns=defaultSpawns(now);save();toast('สร้างจุดทดลองรอบตำแหน่งปัจจุบันแล้ว');}
    render();
  },()=>{toast('เปิด GPS ไม่สำเร็จ • ใช้โหมดทดลองได้');$('#statusText').textContent='ไม่พบ GPS';},{enableHighAccuracy:true,maximumAge:2000,timeout:15000});
}

function scheduleActive(s,now=new Date()){
  let mode=String(s.dayMode||'all'),day=now.getDay();
  if(mode==='weekdays'&&(day===0||day===6))return false;
  if(mode==='weekend'&&day!==0&&day!==6)return false;
  let h=now.getHours()+now.getMinutes()/60,start=Number(s.startHour),end=Number(s.endHour);
  if(!Number.isFinite(start))start=0;if(!Number.isFinite(end))end=24;
  if(start===end)return true;
  if(start<end)return h>=start&&h<end;
  return h>=start||h<end;
}
function scheduleText(s){
  let start=Number.isFinite(+s.startHour)?+s.startHour:0,end=Number.isFinite(+s.endHour)?+s.endHour:24,mode=String(s.dayMode||'all');
  let days=mode==='weekdays'?'จ.-ศ.':mode==='weekend'?'ส.-อา.':'ทุกวัน';
  if(start===0&&end===24)return days+' • ทั้งวัน';
  return `${days} • ${String(start).padStart(2,'0')}:00–${String(end).padStart(2,'0')}:00`;
}
function spawnStatus(s){
  let d=hav(state.pos,s),last=+state.collected[s.id]||0,ready=Date.now()-last>(+s.cooldown||86400000),windowActive=scheduleActive(s);
  return {d,ready,windowActive};
}
function allEntries(){return state.spawns.filter(s=>s.active!==false).map(s=>({...s,...spawnStatus(s),item:itemById(s.itemId)})).filter(x=>x.item).sort((a,b)=>a.d-b.d);}
function todayRarePlus(){let t=state.todayStats||{};return (+t.rare||0)+(+t.epic||0)+(+t.legendary||0);}
function missionGoals(){return {collect:+CFG.DAILY_COLLECT_GOAL||3,rare:+CFG.DAILY_RARE_GOAL||1,walk:+((CFG.DAILY_WALK_GOAL_BY_GRADE||{})[state.grade]||160)};}
function renderMissions(){
  let g=missionGoals(),collect=+state.todayCount||0,rare=todayRarePlus(),walk=Math.round(+state.walk.meters||0);
  let rows=[
    {icon:'🎒',label:`เก็บของ ${g.collect} ชิ้น`,v:collect,g:g.collect},
    {icon:'💜',label:`พบ Rare ขึ้นไป ${g.rare} ชิ้น`,v:rare,g:g.rare},
    {icon:'🚶',label:`เดินสำรวจ ${g.walk} เมตร`,v:walk,g:g.walk}
  ];
  let done=rows.filter(x=>x.v>=x.g).length,pct=rows.reduce((a,x)=>a+Math.min(1,x.v/x.g),0)/rows.length*100;
  $('#missionBar').style.width=pct+'%';$('#missionText').textContent=done===3?'สำเร็จครบทุกภารกิจแล้ว! 🎉':`สำเร็จ ${done}/3 ภารกิจ`;
  $('#missionList').innerHTML=rows.map(x=>`<div class="missionRow ${x.v>=x.g?'done':''}"><span>${x.v>=x.g?'✅':x.icon}</span><b>${esc(x.label)}</b><span>${Math.min(x.v,x.g)}/${x.g}</span></div>`).join('');
}

function render(){
  if(!state.pos)return;
  let entries=allEntries();
  $('#statusText').textContent=state.demo?'โหมดทดลอง • จำลองตำแหน่ง':state.cloud?'กำลังสำรวจ • ออนไลน์':'กำลังสำรวจ • ในเครื่อง';
  $('#gpsAccuracy').textContent=state.demo?'Demo':`GPS ±${state.acc||'?'} m`;$('#bagCount').textContent=sumBag();
  renderMissions();renderLegendary(entries);renderRadar(entries);renderMap(entries);renderNearby(entries);
}
function renderRadar(entries){
  let radar=$('#radar');radar.querySelectorAll('.ping').forEach(x=>x.remove());
  entries.filter(x=>x.ready&&x.windowActive&&x.d<130).slice(0,14).forEach(e=>{let ang=rad(bearing(state.pos,e)),rr=Math.min(46,e.d/130*46),x=50+Math.sin(ang)*rr,y=50-Math.cos(ang)*rr,p=document.createElement('div');p.className='ping '+e.item.rarity;p.style.left=x+'%';p.style.top=y+'%';p.title=e.item.name;radar.appendChild(p);});
}
function renderMap(entries){
  let svg=$('#missionMap');if(!svg)return;let range=+state.mapRange||150,cx=160,cy=160,scale=128/range;
  let parts=['<circle class="mapGrid" cx="160" cy="160" r="43"/><circle class="mapGrid" cx="160" cy="160" r="86"/><circle class="mapGrid" cx="160" cy="160" r="128"/><line class="mapAxis" x1="32" y1="160" x2="288" y2="160"/><line class="mapAxis" x1="160" y1="32" x2="160" y2="288"/>'];
  entries.filter(e=>e.d<=range*1.05).slice(0,40).forEach(e=>{
    let dLat=(e.lat-state.pos.lat)*111111,dLng=(e.lng-state.pos.lng)*111111*Math.cos(rad(state.pos.lat));
    let x=cx+dLng*scale,y=cy-dLat*scale,radSize=e.item.rarity==='legendary'?8:e.item.rarity==='epic'?7:e.item.rarity==='rare'?6:5;
    x=Math.max(24,Math.min(296,x));y=Math.max(24,Math.min(296,y));
    parts.push(`<circle class="mapSpawn ${e.item.rarity} ${e.windowActive&&e.ready?'':'closed'}" data-spawn="${esc(e.id)}" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${radSize}"/>`);
  });
  parts.push('<circle class="mapMe" cx="160" cy="160" r="7"/>');parts.push('<path d="M160 145 L154 158 L166 158 Z" fill="#fff"/>');
  svg.innerHTML=parts.join('');
  svg.querySelectorAll('[data-spawn]').forEach(n=>n.addEventListener('click',()=>{let e=entries.find(x=>x.id===n.dataset.spawn);if(!e)return;$('#mapHint').textContent=`${e.d<25?e.item.name:'สัญญาณ '+rarityLabel[e.item.rarity]} • ${Math.round(e.d)} ม. • ${e.windowActive?(e.ready?'พร้อมเก็บ':'รอเกิดใหม่'):'ยังไม่ถึงเวลา'} • ${scheduleText(e)}`;}));
}
function renderNearby(entries){
  let near=$('#nearby');near.innerHTML='';
  entries.slice(0,5).forEach(e=>{
    let can=e.ready&&e.windowActive&&e.d<=(+e.radius||18),card=document.createElement('div');
    card.className='nearCard '+(!e.windowActive?'closed ':'')+(e.item.rarity==='legendary'?'legendaryCard':'');
    let label=e.d<20?esc(e.item.name):'??? สัญญาณ '+rarityLabel[e.item.rarity];
    let sub=!e.windowActive?`ยังไม่ถึงเวลา • ${scheduleText(e)}`:!e.ready?'เก็บแล้ว • รอเกิดใหม่':`${Math.round(e.d)} เมตร${e.label?' • '+esc(e.label):''}`;
    card.innerHTML=`<img src="${e.item.img}" alt="${esc(e.item.name)}"><div class="meta"><b>${label}</b><span class="rarityChip ${e.item.rarity}">${rarityLabel[e.item.rarity]}</span><small>${sub}</small></div><button ${can?'':'disabled'}>${can?'เปิด AR':!e.windowActive?'ปิดอยู่':'เดินเข้าใกล้'}</button>`;
    card.querySelector('button').onclick=()=>openAR(e);near.appendChild(card);
  });
  if(!entries.length)near.innerHTML='<div class="emptyState">ยังไม่มีจุดเกิดของ • ให้ครูตั้งจุดในโหมดครู</div>';
}
function renderLegendary(entries){
  let lim=+CFG.LEGENDARY_ALERT_RADIUS_M||250;
  let lg=entries.find(e=>e.item.rarity==='legendary'&&e.windowActive&&e.ready&&e.d<=lim);
  let banner=$('#legendaryBanner');
  if(!lg){banner.classList.add('hidden');return;}
  banner.classList.remove('hidden');$('#legendaryText').textContent=`สัญญาณอยู่ห่างประมาณ ${Math.round(lg.d)} เมตร${lg.label?' • '+lg.label:''}`;
  if(!state.legendarySeen[lg.id]){state.legendarySeen[lg.id]=Date.now();save();if(navigator.vibrate)navigator.vibrate([100,70,160]);toast('👑 ตรวจพบสัญญาณ Legendary!');}
}

$('#radarViewBtn').onclick=()=>{state.view='radar';$('#radarViewBtn').classList.add('active');$('#mapViewBtn').classList.remove('active');$('#radarWrap').classList.remove('hidden');$('#mapWrap').classList.add('hidden');};
$('#mapViewBtn').onclick=()=>{state.view='map';$('#mapViewBtn').classList.add('active');$('#radarViewBtn').classList.remove('active');$('#mapWrap').classList.remove('hidden');$('#radarWrap').classList.add('hidden');render();};
$('#mapRange').value=String(state.mapRange||150);$('#mapRange').onchange=e=>{state.mapRange=+e.target.value||150;save();render();};

function moveDemo(){
  if(!state.demo||!state.pos)return;let nearest=allEntries().filter(x=>x.windowActive&&x.ready).find(x=>x.d>4);
  if(!nearest)return toast('อยู่ใกล้จุดเกิดแล้ว');let before=nearest.d,f=Math.min(.45,10/nearest.d);
  state.pos={lat:state.pos.lat+(nearest.lat-state.pos.lat)*f,lng:state.pos.lng+(nearest.lng-state.pos.lng)*f,t:Date.now()};state.walk.meters=(+state.walk.meters||0)+Math.min(10,before);save();render();toast('จำลองเดินเข้าใกล้ '+Math.max(0,Math.round(before-10))+' ม.');
}
function nearestReady(){return allEntries().filter(x=>x.ready&&x.windowActive)[0];}
$('#arNav').onclick=()=>{let n=nearestReady();if(!n)return toast('ยังไม่พบสัญญาณที่พร้อมเกิด');if(n.d>(+n.radius||18))return toast('ต้องเข้าใกล้อีก '+Math.ceil(n.d-(+n.radius||18))+' เมตร');openAR(n);};
async function openAR(sp){
  if(!sp.windowActive)return toast('วัตถุนี้ยังไม่ถึงเวลาเกิด');if(!sp.ready)return toast('จุดนี้ยังรอเกิดใหม่');
  state.activeSpawn=sp;show('arScreen');$('#arItemImg').src=sp.item.img;$('#arDistance').textContent=Math.round(sp.d)+' m';$('#arRarity').textContent=rarityLabel[sp.item.rarity];$('#arRarity').className='glass pill rarityChip '+sp.item.rarity;$('#arHint').textContent='พบ '+sp.item.name+' • แตะเพื่อปลดล็อก';$('#arScreen').classList.toggle('legendaryAR',sp.item.rarity==='legendary');
  try{state.camera=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});$('#camera').srcObject=state.camera;$('.cameraFallback').style.display='none';}
  catch(e){$('.cameraFallback').style.display='block';toast(window.isSecureContext?'ใช้ AR จำลอง เนื่องจากเปิดกล้องไม่ได้':'ต้องเปิดผ่าน HTTPS เพื่อใช้กล้อง AR');}
}
function closeAR(){if(state.camera){state.camera.getTracks().forEach(t=>t.stop());state.camera=null;}$('#arScreen').classList.remove('legendaryAR');show('main');render();}
$('#closeAr').onclick=closeAR;
$('#arItemBtn').onclick=()=>{if(state.speed>1.8&&!state.demo)return toast('เพื่อความปลอดภัย กรุณาหยุดเดินก่อนแก้โจทย์');makeQuestion();$('#mathModal').classList.add('show');};

function makeQuestion(){
  let g=state.grade,a,b,c,q,ans;
  for(let tries=0;tries<160;tries++){
    if(g===4){let type=Math.floor(Math.random()*4);if(type===0){a=r(10,499);b=r(10,499);ans=a+b;q=`${a} + ${b} = ?`;}else if(type===1){a=r(50,999);b=r(10,a);ans=a-b;q=`${a} − ${b} = ?`;}else if(type===2){a=r(2,12);b=r(2,25);ans=a*b;q=`${a} × ${b} = ?`;}else{b=r(2,12);ans=r(2,50);a=b*ans;q=`${a} ÷ ${b} = ?`;}}
    else if(g===5){if(Math.random()<.5){a=r(20,300);b=r(2,12);c=r(5,70);ans=a+b*c;q=`${a} + ${b} × ${c} = ?`;}else{b=r(2,12);c=r(2,20);a=b*c+r(20,300);ans=a-b*c;q=`${a} − ${b} × ${c} = ?`;}}
    else{let t=Math.random();if(t<.34){a=r(5,40);b=r(2,12);c=r(5,90);ans=a*b+c;q=`${a} × ${b} + ${c} = ?`;}else if(t<.67){b=r(2,12);c=r(2,30);a=b*c;let d=r(5,120);ans=a/b+d;q=`${a} ÷ ${b} + ${d} = ?`;}else{a=r(100,900);b=r(2,9);c=r(2,20);ans=a-b*c;q=`${a} − ${b} × ${c} = ?`;}}
    if(Number.isInteger(ans)&&ans>=0&&ans<=999)break;
  }
  state.question={q,ans};state.answer='';$('#question').textContent=q;renderAnswer();
}
function renderAnswer(){$('#answer').textContent=state.answer.padEnd(3,'_').split('').join(' ');}
let keypad=$('.keypad');[1,2,3,4,5,6,7,8,9,'⌫',0,'✓'].forEach(v=>{let b=document.createElement('button');b.textContent=v;if(v==='⌫')b.className='del';if(v==='✓')b.className='ok';b.onclick=()=>{if(v==='⌫')state.answer=state.answer.slice(0,-1);else if(v==='✓')checkAnswer();else if(state.answer.length<3)state.answer+=v;renderAnswer();};keypad.appendChild(b);});
function checkAnswer(){if(state.answer==='')return;if(+state.answer===state.question.ans){$('#mathModal').classList.remove('show');collect();}else{toast('ยังไม่ถูก ลองคำนวณอีกครั้ง');$('.modalCard').animate([{transform:'translateX(-8px)'},{transform:'translateX(8px)'},{transform:'translateX(0)'}],{duration:250});state.answer='';renderAnswer();}}
$('#cancelMath').onclick=()=>$('#mathModal').classList.remove('show');

function completedSets(){let out=[];for(let s=1;s<=18;s++){let list=ITEMS.filter(i=>i.set===s);if(list.length&&list.every(i=>+state.inventory[i.id]>0))out.push(s);}return out;}
function showSetComplete(setNo){let list=ITEMS.filter(i=>i.set===setNo);if(!list.length)return;$('#setCompleteTitle').textContent='สะสมครบ Set '+setNo+'!';$('#setCompleteText').textContent=list[0].setName+' ครบ '+list.length+' ชนิด • ได้ตรา Collection Master';$('#setComplete').classList.add('show');}
$('#closeSetComplete').onclick=()=>$('#setComplete').classList.remove('show');
async function collect(){
  let sp=state.activeSpawn,it=sp&&sp.item;if(!sp||!it)return;
  if(!scheduleActive(sp))return toast('ช่วงเวลาการเกิดสิ้นสุดแล้ว');
  let beforeSets=new Set(completedSets()),oldInv=state.inventory[it.id]||0,oldCol=state.collected[sp.id]||0,oldToday=state.todayCount,oldStats={...state.todayStats};
  state.inventory[it.id]=oldInv+1;state.collected[sp.id]=Date.now();state.todayCount=oldToday+1;state.todayStats[it.rarity]=(+state.todayStats[it.rarity]||0)+1;state.lastCollectRarity=it.rarity;save();
  document.body.insertAdjacentHTML('beforeend','<div class="successFx"></div>');setTimeout(()=>$('.successFx')?.remove(),800);toast('✨ ได้รับ '+it.name+' ×1');
  if(state.cloud&&!state.demo){
    try{let d=await api('collect',{studentCode:state.studentCode,spawnId:sp.id,itemId:it.id,question:state.question?.q||''});if(d.inventory)state.inventory=d.inventory;if(d.collected)state.collected=d.collected;if(Number.isFinite(+d.todayCount))state.todayCount=+d.todayCount;if(d.todayStats)state.todayStats=Object.assign({common:0,rare:0,epic:0,legendary:0},d.todayStats);if(Array.isArray(d.leaderboard))state.leaderboard=d.leaderboard;save();}
    catch(e){state.inventory[it.id]=oldInv;state.collected[sp.id]=oldCol;if(!oldCol)delete state.collected[sp.id];state.todayCount=oldToday;state.todayStats=oldStats;save();toast('ซิงก์ไม่สำเร็จ • ยังไม่นับชิ้นนี้ในระบบกลาง');setTimeout(closeAR,650);return;}
  }
  let afterSets=completedSets().filter(s=>!beforeSets.has(s));if(afterSets.length)setTimeout(()=>showSetComplete(afterSets[0]),850);
  setTimeout(closeAR,650);
}

function panel(tab){
  show('panel');let title=$('#panelTitle'),body=$('#panelBody');body.innerHTML='';
  if(tab==='bag'){
    title.textContent='🎒 กระเป๋า 4 มิติ';body.innerHTML=`<div class="panelStats"><b>${sumBag()}</b><span>ชิ้นทั้งหมด</span><b>${uniqueBag()}</b><span>ชนิดที่พบ</span></div><h3 class="sectionTitle">ของสะสมทั้งหมด</h3><div class="panelGrid"></div>`;
    let grid=body.querySelector('.panelGrid');ITEMS.filter(it=>state.inventory[it.id]).sort((a,b)=>a.set-b.set||rarityRank[b.rarity]-rarityRank[a.rarity]).forEach(it=>{let d=document.createElement('div');d.className='itemCard';d.innerHTML=`<span class="countBadge">×${state.inventory[it.id]}</span><img src="${it.img}" alt="${esc(it.name)}"><b>${esc(it.name)}</b><span class="rarityChip ${it.rarity}">${rarityLabel[it.rarity]}</span><small>Set ${it.set} • ${esc(it.setName)}</small>`;grid.appendChild(d);});if(!grid.children.length)grid.innerHTML='<p>ยังไม่มีของสะสม ออกเดินหาได้เลย!</p>';
  }
  if(tab==='dex'){
    title.textContent='📚 Dimension Dex';let sets=[...new Set(ITEMS.map(x=>x.set))];
    sets.forEach(s=>{let list=ITEMS.filter(x=>x.set===s),got=list.filter(x=>state.inventory[x.id]).length,complete=got===list.length,d=document.createElement('div');d.className='dexSet '+(complete?'complete':'');d.innerHTML=`<div class="dexHead"><b>Set ${s} • ${esc(list[0].setName)}</b><span>${got}/${list.length}</span></div>${complete?'<div class="dexComplete">🏆 COLLECTION COMPLETE</div>':''}<div class="dexBar"><i style="width:${got/list.length*100}%"></i></div>`;body.appendChild(d);});
  }
  if(tab==='rank'){title.textContent='🏆 ตารางคะแนน';renderRank(body);}
  if(tab==='settings'){title.textContent='⚙️ ตั้งค่า';renderSettings(body);}
}
$$('[data-tab]').forEach(b=>b.onclick=()=>{if(b.dataset.tab==='radar'){show('main');render();}else panel(b.dataset.tab);});$('#backPanel').onclick=()=>{show('main');render();};
async function renderRank(body){
  body.innerHTML='<div class="rankIntro">จัดอันดับจากจำนวนของที่เก็บสะสมทั้งหมด</div><div id="rankList" class="rankList"><div class="loading">กำลังโหลด...</div></div>';
  if(state.cloud){try{let d=await api('leaderboard',{studentCode:state.studentCode});state.leaderboard=d.leaderboard||[];save();}catch(e){}}
  let list=(state.leaderboard||[]).filter(x=>!['A','B'].includes(String(x.code||'').toUpperCase()));if(!list.length&&state.student&&!['A','B'].includes(String(state.studentCode||'').toUpperCase()))list=[{code:state.studentCode,name:state.student,grade:state.grade,total:sumBag(),unique:uniqueBag()}];
  $('#rankList').innerHTML=list.slice(0,30).map((x,i)=>`<div class="rankRow ${x.code===state.studentCode?'meRow':''}"><div class="rankNo">${i<3?['🥇','🥈','🥉'][i]:i+1}</div><div><b>${esc(x.name)}</b><small>ป.${esc(x.grade)} • พบ ${esc(x.unique||0)} ชนิด</small></div><strong>${esc(x.total||0)}</strong></div>`).join('')||'<div class="emptyState">ยังไม่มีข้อมูลอันดับ</div>';
}
function renderSettings(body){
  body.innerHTML=`<div class="settings"><div class="block"><b>บัญชีผู้เล่น</b><p>${esc(state.studentCode)} • ${esc(state.student)} • ป.${state.grade}</p><div class="statusLine"><span class="syncDot ${state.cloud?'ok':'local'}"></span>${state.cloud?'เชื่อมข้อมูล Google Sheet':'ใช้ข้อมูลเฉพาะเครื่อง'}</div>${state.cloud?'<button id="syncNow">☁️ ซิงก์เดี๋ยวนี้</button>':''}<div class="dailyStats"><div><b>${state.todayCount}</b>วันนี้</div><div><b>${todayRarePlus()}</b>Rare+</div><div><b>${Math.round(state.walk.meters||0)}</b>เมตร</div><div><b>${completedSets().length}</b>ครบเซ็ต</div></div></div><div class="block"><b>โหมดทดสอบ</b><p>ใช้ปุ่มนี้บนคอมเพื่อจำลองการเดินเข้าหาจุดใกล้ที่สุด</p><button id="walkDemo">🚶 จำลองเดิน 10 เมตร</button></div><div class="block"><b>โหมดครู — ตั้งจุดเกิดของ</b><p>กรอกรหัสครูเพื่อจัดการจุดเกิดและกำหนดช่วงเวลา</p><input id="teachCode" type="password" inputmode="numeric" placeholder="รหัสครู"><button id="teacherOpen">เปิดโหมดครู</button></div><div class="block"><b>ข้อมูลในเครื่อง</b><button id="resetCollect">ล้างแคชของสะสมในเครื่อง</button><button id="resetAll">ออกจากระบบ / รีเซ็ตเครื่องนี้</button></div></div>`;
  $('#walkDemo').onclick=moveDemo;if($('#syncNow'))$('#syncNow').onclick=()=>cloudBootstrap();$('#teacherOpen').onclick=()=>teacherLogin(body);
  $('#resetCollect').onclick=()=>{state.inventory={};state.collected={};state.todayCount=0;state.todayStats={common:0,rare:0,epic:0,legendary:0};save();toast('ล้างข้อมูลในเครื่องแล้ว • ซิงก์ใหม่เพื่อดึงข้อมูลกลาง');};
  $('#resetAll').onclick=()=>{localStorage.removeItem(STORE);localStorage.removeItem(OLD_STORE);location.reload();};
}
async function teacherLogin(body){let code=$('#teachCode').value.trim();if(!state.cloud){if(code===state.teacherCode)return teacherPanel(body,code);return toast('รหัสครูไม่ถูกต้อง');}try{await api('teacherOverview',{teacherCode:code});teacherPanel(body,code);}catch(e){toast('รหัสครูไม่ถูกต้อง หรือเชื่อมต่อไม่ได้');}}
async function teacherPanel(body,teacherCode){
  body.innerHTML=`<div class="settings"><div id="teacherStats" class="teacherStats"></div><div class="block"><b>📍 เพิ่มจุดเกิด ณ ตำแหน่งนี้</b><p>เดินไปยังตำแหน่งที่ต้องการ เลือกของ และกำหนดช่วงเวลาเกิด</p><select id="teacherItem"></select><input id="spawnLabel" maxlength="50" placeholder="ชื่อจุด เช่น หน้าห้องสมุด"><div class="row2"><label>รัศมี (ม.)<input id="radius" type="number" min="5" max="50" value="18"></label><label>เกิดใหม่ (ชม.)<input id="cooldownHours" type="number" min="1" max="168" value="24"></label></div><div class="teacherSchedule"><label>เริ่มเกิด<input id="startHour" type="number" min="0" max="23" value="0"></label><label>หยุดเกิด<input id="endHour" type="number" min="1" max="24" value="24"></label><label>วันที่เกิด<select id="dayMode"><option value="all">ทุกวัน</option><option value="weekdays">จันทร์–ศุกร์</option><option value="weekend">เสาร์–อาทิตย์</option></select></label></div><button id="addHere">＋ บันทึกจุดเกิดตรงนี้</button>${!state.cloud?'<button id="regen">สร้างจุดทดลอง 24 จุด</button>':''}</div><div class="block"><b>จุดที่ตั้งไว้</b><div id="spawnList"></div></div>${!state.cloud?'<div class="block"><b>ย้ายข้อมูลจุดเกิด</b><textarea id="cfg" rows="5"></textarea><button id="exportCfg">ส่งออก JSON</button><button id="importCfg">นำเข้า JSON</button></div><div class="block"><b>เปลี่ยนรหัสครูในเครื่อง</b><input id="newCode" inputmode="numeric" value="'+esc(state.teacherCode)+'"><button id="saveCode">บันทึกรหัส</button></div>':''}</div>`;
  let sel=$('#teacherItem');ITEMS.slice().sort((a,b)=>rarityRank[a.rarity]-rarityRank[b.rarity]||a.set-b.set).forEach(i=>{let o=document.createElement('option');o.value=i.id;o.textContent=`[${rarityLabel[i.rarity]}] Set ${i.set} • ${i.name}`;sel.appendChild(o);});
  let draw=()=>{let entries=state.spawns.map((s,i)=>{let it=itemById(s.itemId);return `<div class="spawnRow"><div><b>${i+1}. ${esc(it?.name||s.itemId)}</b><span class="rarityChip ${it?.rarity||'common'}">${rarityLabel[it?.rarity||'common']}</span><small>${esc(s.label||'ไม่ระบุชื่อจุด')} • ${s.radius||18} ม. • ${Math.round((s.cooldown||86400000)/3600000)} ชม. <span class="scheduleTag">${scheduleText(s)}</span></small></div><button data-del="${i}">ลบ</button></div>`;}).join('');$('#spawnList').innerHTML=entries||'<div class="emptyState">ยังไม่มีจุดเกิด</div>';$$('[data-del]').forEach(b=>b.onclick=async()=>{let s=state.spawns[+b.dataset.del];if(state.cloud){try{await api('deleteSpawn',{teacherCode,spawnId:s.id});await refreshTeacher(teacherCode,draw);}catch(e){toast('ลบไม่สำเร็จ');}}else{state.spawns.splice(+b.dataset.del,1);save();draw();}});};draw();
  async function refreshTeacher(code,after){if(!state.cloud)return;try{let d=await api('teacherOverview',{teacherCode:code});state.spawns=d.spawns||state.spawns;let st=d.stats||{};$('#teacherStats').innerHTML=`<div><b>${st.students||0}</b><span>นักเรียน</span></div><div><b>${st.collections||0}</b><span>เก็บทั้งหมด</span></div><div><b>${st.today||0}</b><span>วันนี้</span></div><div><b>${state.spawns.length}</b><span>จุดเกิด</span></div>`;save();after&&after();}catch(e){$('#teacherStats').innerHTML='<div class="emptyState">โหลดสรุปครูไม่สำเร็จ</div>';}}
  await refreshTeacher(teacherCode,draw);
  $('#addHere').onclick=async()=>{if(!state.pos)return toast('ยังไม่มีพิกัด GPS');let start=Math.max(0,Math.min(23,+$('#startHour').value||0)),end=Math.max(1,Math.min(24,+$('#endHour').value||24));let spawn={id:'p'+Date.now(),lat:state.pos.lat,lng:state.pos.lng,itemId:sel.value,radius:+$('#radius').value||18,cooldown:(+$('#cooldownHours').value||24)*3600000,label:$('#spawnLabel').value.trim(),active:true,startHour:start,endHour:end,dayMode:$('#dayMode').value};if(state.cloud){try{await api('saveSpawn',{teacherCode,spawn});toast('บันทึกจุดเกิดขึ้นระบบกลางแล้ว');await refreshTeacher(teacherCode,draw);}catch(e){toast('บันทึกไม่สำเร็จ • '+e.message);}}else{state.spawns.push(spawn);save();draw();toast('บันทึกจุดเกิดแล้ว');}};
  if($('#regen'))$('#regen').onclick=()=>{if(!state.pos)return;state.spawns=defaultSpawns(state.pos);save();draw();toast('สร้าง 24 จุดทดลองแล้ว');};if($('#exportCfg'))$('#exportCfg').onclick=()=>{$('#cfg').value=JSON.stringify(state.spawns,null,2);};if($('#importCfg'))$('#importCfg').onclick=()=>{try{let x=JSON.parse($('#cfg').value);if(!Array.isArray(x))throw 0;state.spawns=x;save();draw();toast('นำเข้าจุดเกิดแล้ว');}catch(e){toast('รูปแบบ JSON ไม่ถูกต้อง');}};if($('#saveCode'))$('#saveCode').onclick=()=>{let c=$('#newCode').value.trim();if(c.length<4)return toast('รหัสควรมีอย่างน้อย 4 ตัว');state.teacherCode=c;save();toast('เปลี่ยนรหัสครูแล้ว');};
}

setInterval(()=>{if($('#main').classList.contains('active'))render();},4000);
setInterval(()=>{if(state.cloud&&state.studentCode&&!state.demo&&!state.syncing)cloudBootstrap(true);},+CFG.CLOUD_SYNC_INTERVAL_MS||60000);
if('serviceWorker'in navigator&&(window.isSecureContext||location.hostname==='localhost'||location.hostname==='127.0.0.1'))navigator.serviceWorker.register('sw.js').catch(()=>{});
})();
