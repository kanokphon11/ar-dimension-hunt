window.ITEMS=[
  {
    "id": "s01_01",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลเปลวไฟ",
    "img": "assets/s01_01.webp",
    "rarity": "common"
  },
  {
    "id": "s01_02",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลน้ำแข็ง",
    "img": "assets/s01_02.webp",
    "rarity": "common"
  },
  {
    "id": "s01_03",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลสายลม",
    "img": "assets/s01_03.webp",
    "rarity": "common"
  },
  {
    "id": "s01_04",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลแสง",
    "img": "assets/s01_04.webp",
    "rarity": "common"
  },
  {
    "id": "s01_05",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลเวท",
    "img": "assets/s01_05.webp",
    "rarity": "common"
  },
  {
    "id": "s01_06",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลจักรวาล",
    "img": "assets/s01_06.webp",
    "rarity": "common"
  },
  {
    "id": "s01_07",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลสุริยะ",
    "img": "assets/s01_07.webp",
    "rarity": "common"
  },
  {
    "id": "s01_08",
    "set": 1,
    "setName": "คริสตัลธาตุ",
    "name": "คริสตัลสายฟ้า",
    "img": "assets/s01_08.webp",
    "rarity": "common"
  },
  {
    "id": "s02_01",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่พฤกษา",
    "img": "assets/s02_01.webp",
    "rarity": "common"
  },
  {
    "id": "s02_02",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่เงามิติ",
    "img": "assets/s02_02.webp",
    "rarity": "common"
  },
  {
    "id": "s02_03",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่สายฟ้า",
    "img": "assets/s02_03.webp",
    "rarity": "common"
  },
  {
    "id": "s02_04",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่ดารา",
    "img": "assets/s02_04.webp",
    "rarity": "common"
  },
  {
    "id": "s02_05",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่ท้องฟ้า",
    "img": "assets/s02_05.webp",
    "rarity": "common"
  },
  {
    "id": "s02_06",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่จักรวาล",
    "img": "assets/s02_06.webp",
    "rarity": "common"
  },
  {
    "id": "s02_07",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่มหาสมุทร",
    "img": "assets/s02_07.webp",
    "rarity": "common"
  },
  {
    "id": "s02_08",
    "set": 2,
    "setName": "ไข่มิติ",
    "name": "ไข่ศิลา",
    "img": "assets/s02_08.webp",
    "rarity": "common"
  },
  {
    "id": "s03_01",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญจันทรา",
    "img": "assets/s03_01.webp",
    "rarity": "common"
  },
  {
    "id": "s03_02",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญวิญญาณ",
    "img": "assets/s03_02.webp",
    "rarity": "common"
  },
  {
    "id": "s03_03",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญเกลียวโบราณ",
    "img": "assets/s03_03.webp",
    "rarity": "common"
  },
  {
    "id": "s03_04",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญสายฟ้า",
    "img": "assets/s03_04.webp",
    "rarity": "common"
  },
  {
    "id": "s03_05",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญวายุ",
    "img": "assets/s03_05.webp",
    "rarity": "common"
  },
  {
    "id": "s03_06",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญดารา",
    "img": "assets/s03_06.webp",
    "rarity": "common"
  },
  {
    "id": "s03_07",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญจักรกล",
    "img": "assets/s03_07.webp",
    "rarity": "common"
  },
  {
    "id": "s03_08",
    "set": 3,
    "setName": "เหรียญโบราณ",
    "name": "เหรียญสุริยะ",
    "img": "assets/s03_08.webp",
    "rarity": "common"
  },
  {
    "id": "s04_01",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "ฟอสซิลกะโหลกไดโนเสาร์",
    "img": "assets/s04_01.webp",
    "rarity": "common"
  },
  {
    "id": "s04_02",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "ฟอสซิลไทรโลไบต์",
    "img": "assets/s04_02.webp",
    "rarity": "common"
  },
  {
    "id": "s04_03",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "ฟอสซิลใบไม้",
    "img": "assets/s04_03.webp",
    "rarity": "common"
  },
  {
    "id": "s04_04",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "อำพันแมลง",
    "img": "assets/s04_04.webp",
    "rarity": "common"
  },
  {
    "id": "s04_05",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "กรงเล็บโบราณ",
    "img": "assets/s04_05.webp",
    "rarity": "common"
  },
  {
    "id": "s04_06",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "ฟอสซิลแอมโมไนต์",
    "img": "assets/s04_06.webp",
    "rarity": "common"
  },
  {
    "id": "s04_07",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "ฟอสซิลปลาหิน",
    "img": "assets/s04_07.webp",
    "rarity": "common"
  },
  {
    "id": "s04_08",
    "set": 4,
    "setName": "ฟอสซิล",
    "name": "อำพันผลึก",
    "img": "assets/s04_08.webp",
    "rarity": "common"
  },
  {
    "id": "s05_01",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "โมดูลวงจร",
    "img": "assets/s05_01.webp",
    "rarity": "common"
  },
  {
    "id": "s05_02",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "เลนส์พลังงาน",
    "img": "assets/s05_02.webp",
    "rarity": "common"
  },
  {
    "id": "s05_03",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "ข้อต่อแขนกล",
    "img": "assets/s05_03.webp",
    "rarity": "common"
  },
  {
    "id": "s05_04",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "เฟืองโบราณ",
    "img": "assets/s05_04.webp",
    "rarity": "common"
  },
  {
    "id": "s05_05",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "แกนพลาสมา",
    "img": "assets/s05_05.webp",
    "rarity": "common"
  },
  {
    "id": "s05_06",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "แผงควบคุม",
    "img": "assets/s05_06.webp",
    "rarity": "common"
  },
  {
    "id": "s05_07",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "เครื่องกำเนิดพลังงาน",
    "img": "assets/s05_07.webp",
    "rarity": "common"
  },
  {
    "id": "s05_08",
    "set": 5,
    "setName": "ชิ้นส่วนจักรกล",
    "name": "เฟืองคริสตัล",
    "img": "assets/s05_08.webp",
    "rarity": "common"
  },
  {
    "id": "s06_01",
    "set": 6,
    "setName": "เศษดาว",
    "name": "ผลึกดาวน้ำแข็ง",
    "img": "assets/s06_01.webp",
    "rarity": "common"
  },
  {
    "id": "s06_02",
    "set": 6,
    "setName": "เศษดาว",
    "name": "เศษดาวจักรวาล",
    "img": "assets/s06_02.webp",
    "rarity": "common"
  },
  {
    "id": "s06_03",
    "set": 6,
    "setName": "เศษดาว",
    "name": "ดาวหาง",
    "img": "assets/s06_03.webp",
    "rarity": "common"
  },
  {
    "id": "s06_04",
    "set": 6,
    "setName": "เศษดาว",
    "name": "เศษผลึกกาแล็กซี",
    "img": "assets/s06_04.webp",
    "rarity": "common"
  },
  {
    "id": "s06_05",
    "set": 6,
    "setName": "เศษดาว",
    "name": "ผลึกดาวทอง",
    "img": "assets/s06_05.webp",
    "rarity": "common"
  },
  {
    "id": "s06_06",
    "set": 6,
    "setName": "เศษดาว",
    "name": "คริสตัลจักรวาลม่วง",
    "img": "assets/s06_06.webp",
    "rarity": "common"
  },
  {
    "id": "s06_07",
    "set": 6,
    "setName": "เศษดาว",
    "name": "คริสตัลดารา",
    "img": "assets/s06_07.webp",
    "rarity": "common"
  },
  {
    "id": "s06_08",
    "set": 6,
    "setName": "เศษดาว",
    "name": "ผลึกสุริยะ",
    "img": "assets/s06_08.webp",
    "rarity": "common"
  },
  {
    "id": "s07_01",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วจันทรา",
    "img": "assets/s07_01.webp",
    "rarity": "common"
  },
  {
    "id": "s07_02",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วเถาวัลย์",
    "img": "assets/s07_02.webp",
    "rarity": "common"
  },
  {
    "id": "s07_03",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วน้ำแข็ง",
    "img": "assets/s07_03.webp",
    "rarity": "common"
  },
  {
    "id": "s07_04",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วสุริยะ",
    "img": "assets/s07_04.webp",
    "rarity": "common"
  },
  {
    "id": "s07_05",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วอาคม",
    "img": "assets/s07_05.webp",
    "rarity": "common"
  },
  {
    "id": "s07_06",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วหัวใจ",
    "img": "assets/s07_06.webp",
    "rarity": "common"
  },
  {
    "id": "s07_07",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วสายฟ้า",
    "img": "assets/s07_07.webp",
    "rarity": "common"
  },
  {
    "id": "s07_08",
    "set": 7,
    "setName": "ลูกแก้วเวทมนตร์",
    "name": "ลูกแก้วแรงโน้มถ่วง",
    "img": "assets/s07_08.webp",
    "rarity": "common"
  },
  {
    "id": "s08_01",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "ดอกไม้เพลิงฟีนิกซ์",
    "img": "assets/s08_01.webp",
    "rarity": "common"
  },
  {
    "id": "s08_02",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "ดอกจันทราคริสตัล",
    "img": "assets/s08_02.webp",
    "rarity": "common"
  },
  {
    "id": "s08_03",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "เห็ดสายรุ้ง",
    "img": "assets/s08_03.webp",
    "rarity": "common"
  },
  {
    "id": "s08_04",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "กล้วยไม้สายฟ้า",
    "img": "assets/s08_04.webp",
    "rarity": "common"
  },
  {
    "id": "s08_05",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "เฟิร์นน้ำแข็ง",
    "img": "assets/s08_05.webp",
    "rarity": "common"
  },
  {
    "id": "s08_06",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "กระบองเพชรมรกต",
    "img": "assets/s08_06.webp",
    "rarity": "common"
  },
  {
    "id": "s08_07",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "ผลสุริยะ",
    "img": "assets/s08_07.webp",
    "rarity": "common"
  },
  {
    "id": "s08_08",
    "set": 8,
    "setName": "พืชวิเศษ",
    "name": "ดอกบัวจักรวาล",
    "img": "assets/s08_08.webp",
    "rarity": "common"
  },
  {
    "id": "s09_01",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "มัดสมุนไพร",
    "img": "assets/s09_01.webp",
    "rarity": "common"
  },
  {
    "id": "s09_02",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "ลูกโอ๊กทอง",
    "img": "assets/s09_02.webp",
    "rarity": "common"
  },
  {
    "id": "s09_03",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "โคนสนอำพัน",
    "img": "assets/s09_03.webp",
    "rarity": "common"
  },
  {
    "id": "s09_04",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "รวงน้ำผึ้ง",
    "img": "assets/s09_04.webp",
    "rarity": "common"
  },
  {
    "id": "s09_05",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "หอยมุกสายรุ้ง",
    "img": "assets/s09_05.webp",
    "rarity": "common"
  },
  {
    "id": "s09_06",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "ขนนกยูงวิเศษ",
    "img": "assets/s09_06.webp",
    "rarity": "common"
  },
  {
    "id": "s09_07",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "ฝักเมล็ดอำพัน",
    "img": "assets/s09_07.webp",
    "rarity": "common"
  },
  {
    "id": "s09_08",
    "set": 9,
    "setName": "วัตถุดิบธรรมชาติ",
    "name": "พวงเบอร์รีเวท",
    "img": "assets/s09_08.webp",
    "rarity": "common"
  },
  {
    "id": "s10_01",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "ภูตใบไม้",
    "img": "assets/s10_01.webp",
    "rarity": "common"
  },
  {
    "id": "s10_02",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "มังกรผีเสื้อ",
    "img": "assets/s10_02.webp",
    "rarity": "common"
  },
  {
    "id": "s10_03",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "ภูตเห็ด",
    "img": "assets/s10_03.webp",
    "rarity": "common"
  },
  {
    "id": "s10_04",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "ภูตหยดน้ำ",
    "img": "assets/s10_04.webp",
    "rarity": "common"
  },
  {
    "id": "s10_05",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "ภูตหิ่งห้อย",
    "img": "assets/s10_05.webp",
    "rarity": "common"
  },
  {
    "id": "s10_06",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "โกเลมหินน้อย",
    "img": "assets/s10_06.webp",
    "rarity": "common"
  },
  {
    "id": "s10_07",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "ด้วงคริสตัล",
    "img": "assets/s10_07.webp",
    "rarity": "common"
  },
  {
    "id": "s10_08",
    "set": 10,
    "setName": "สิ่งมีชีวิตจิ๋ว",
    "name": "ภูตเมฆ",
    "img": "assets/s10_08.webp",
    "rarity": "common"
  },
  {
    "id": "s11_01",
    "set": 11,
    "setName": "หีบลึกลับ",
    "name": "หีบสุริยันเพลิง",
    "img": "assets/s11_01.webp",
    "rarity": "rare"
  },
  {
    "id": "s11_02",
    "set": 11,
    "setName": "หีบลึกลับ",
    "name": "หีบจันทราคริสตัล",
    "img": "assets/s11_02.webp",
    "rarity": "rare"
  },
  {
    "id": "s11_03",
    "set": 11,
    "setName": "หีบลึกลับ",
    "name": "หีบพงไพร",
    "img": "assets/s11_03.webp",
    "rarity": "rare"
  },
  {
    "id": "s11_04",
    "set": 11,
    "setName": "หีบลึกลับ",
    "name": "หีบราชินีแห่งทะเล",
    "img": "assets/s11_04.webp",
    "rarity": "rare"
  },
  {
    "id": "s11_05",
    "set": 11,
    "setName": "หีบลึกลับ",
    "name": "หีบต้องสาป",
    "img": "assets/s11_05.webp",
    "rarity": "rare"
  },
  {
    "id": "s11_06",
    "set": 11,
    "setName": "หีบลึกลับ",
    "name": "หีบจักรวาล",
    "img": "assets/s11_06.webp",
    "rarity": "rare"
  },
  {
    "id": "s12_01",
    "set": 12,
    "setName": "หนังสือความรู้",
    "name": "หนังสือธาตุไฟ",
    "img": "assets/s12_01.webp",
    "rarity": "rare"
  },
  {
    "id": "s12_02",
    "set": 12,
    "setName": "หนังสือความรู้",
    "name": "หนังสือธาตุน้ำ",
    "img": "assets/s12_02.webp",
    "rarity": "rare"
  },
  {
    "id": "s12_03",
    "set": 12,
    "setName": "หนังสือความรู้",
    "name": "หนังสือพฤกษา",
    "img": "assets/s12_03.webp",
    "rarity": "rare"
  },
  {
    "id": "s12_04",
    "set": 12,
    "setName": "หนังสือความรู้",
    "name": "หนังสือแสงสุริยะ",
    "img": "assets/s12_04.webp",
    "rarity": "rare"
  },
  {
    "id": "s12_05",
    "set": 12,
    "setName": "หนังสือความรู้",
    "name": "หนังสือเวทมนตร์ลึกลับ",
    "img": "assets/s12_05.webp",
    "rarity": "rare"
  },
  {
    "id": "s12_06",
    "set": 12,
    "setName": "หนังสือความรู้",
    "name": "หนังสือความรู้โบราณ",
    "img": "assets/s12_06.webp",
    "rarity": "rare"
  },
  {
    "id": "s13_01",
    "set": 13,
    "setName": "อัญมณีธาตุพิเศษ",
    "name": "ทับทิมเพลิง",
    "img": "assets/s13_01.webp",
    "rarity": "epic"
  },
  {
    "id": "s13_02",
    "set": 13,
    "setName": "อัญมณีธาตุพิเศษ",
    "name": "อัญมณีวังวนน้ำ",
    "img": "assets/s13_02.webp",
    "rarity": "epic"
  },
  {
    "id": "s13_03",
    "set": 13,
    "setName": "อัญมณีธาตุพิเศษ",
    "name": "มรกตพิภพ",
    "img": "assets/s13_03.webp",
    "rarity": "epic"
  },
  {
    "id": "s13_04",
    "set": 13,
    "setName": "อัญมณีธาตุพิเศษ",
    "name": "คริสตัลวายุ",
    "img": "assets/s13_04.webp",
    "rarity": "epic"
  },
  {
    "id": "s13_05",
    "set": 13,
    "setName": "อัญมณีธาตุพิเศษ",
    "name": "คริสตัลทองคำ",
    "img": "assets/s13_05.webp",
    "rarity": "epic"
  },
  {
    "id": "s13_06",
    "set": 13,
    "setName": "อัญมณีธาตุพิเศษ",
    "name": "คริสตัลจักรวาล",
    "img": "assets/s13_06.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_01",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "ลูกบาศก์พอร์ทัล",
    "img": "assets/s14_01.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_02",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "คริสตัลมิติ",
    "img": "assets/s14_02.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_03",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "แอสโทรเลบมิติ",
    "img": "assets/s14_03.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_04",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "เครื่องรางเกลียวมิติ",
    "img": "assets/s14_04.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_05",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "ลูกแก้วแรงโน้มถ่วง",
    "img": "assets/s14_05.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_06",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "ปริซึมจักรวาล",
    "img": "assets/s14_06.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_07",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "ออบลิสก์เหนือมิติ",
    "img": "assets/s14_07.webp",
    "rarity": "epic"
  },
  {
    "id": "s14_08",
    "set": 14,
    "setName": "วัตถุจากต่างมิติ",
    "name": "นาฬิกาทรายจักรวาล",
    "img": "assets/s14_08.webp",
    "rarity": "epic"
  },
  {
    "id": "s15_01",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราราชันย์ดาวทอง",
    "img": "assets/s15_01.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_02",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราคัมภีร์ดวงดาว",
    "img": "assets/s15_02.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_03",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราต้นไม้มรกต",
    "img": "assets/s15_03.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_04",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราศิลปะและดนตรี",
    "img": "assets/s15_04.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_05",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราวิทยาศาสตร์อาคม",
    "img": "assets/s15_05.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_06",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราเรขาคณิต",
    "img": "assets/s15_06.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_07",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราชัยชนะ",
    "img": "assets/s15_07.webp",
    "rarity": "rare"
  },
  {
    "id": "s15_08",
    "set": 15,
    "setName": "ป้ายตราโรงเรียน",
    "name": "ตราปีกแห่งดวงดาว",
    "img": "assets/s15_08.webp",
    "rarity": "rare"
  },
  {
    "id": "s16_01",
    "set": 16,
    "setName": "ขวดบันทึกความทรงจำ",
    "name": "ขวดรุ่งอรุณโรงเรียน",
    "img": "assets/s16_01.webp",
    "rarity": "rare"
  },
  {
    "id": "s16_02",
    "set": 16,
    "setName": "ขวดบันทึกความทรงจำ",
    "name": "ขวดหัวใจมิตรภาพ",
    "img": "assets/s16_02.webp",
    "rarity": "rare"
  },
  {
    "id": "s16_03",
    "set": 16,
    "setName": "ขวดบันทึกความทรงจำ",
    "name": "ขวดความรู้",
    "img": "assets/s16_03.webp",
    "rarity": "rare"
  },
  {
    "id": "s16_04",
    "set": 16,
    "setName": "ขวดบันทึกความทรงจำ",
    "name": "ขวดสนามเด็กเล่น",
    "img": "assets/s16_04.webp",
    "rarity": "rare"
  },
  {
    "id": "s16_05",
    "set": 16,
    "setName": "ขวดบันทึกความทรงจำ",
    "name": "ขวดท่วงทำนอง",
    "img": "assets/s16_05.webp",
    "rarity": "rare"
  },
  {
    "id": "s16_06",
    "set": 16,
    "setName": "ขวดบันทึกความทรงจำ",
    "name": "ขวดจักรวาล",
    "img": "assets/s16_06.webp",
    "rarity": "rare"
  },
  {
    "id": "s17_01",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราเปลวเพลิง",
    "img": "assets/s17_01.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_02",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราวังวนน้ำแข็ง",
    "img": "assets/s17_02.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_03",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราภูผามรกต",
    "img": "assets/s17_03.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_04",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราวายุ",
    "img": "assets/s17_04.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_05",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราสายฟ้า",
    "img": "assets/s17_05.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_06",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราสุริยะ",
    "img": "assets/s17_06.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_07",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราจันทราเพลิงม่วง",
    "img": "assets/s17_07.webp",
    "rarity": "epic"
  },
  {
    "id": "s17_08",
    "set": 17,
    "setName": "สัญลักษณ์แห่งพลัง",
    "name": "ตราดวงตาจักรวาล",
    "img": "assets/s17_08.webp",
    "rarity": "epic"
  },
  {
    "id": "s18_01",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "โล่สุริยะศักดิ์สิทธิ์",
    "img": "assets/s18_01.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_02",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "มงกุฎแห่งดวงดาว",
    "img": "assets/s18_02.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_03",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "ดาบคริสตัลจักรวาล",
    "img": "assets/s18_03.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_04",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "คทาจักรวาล",
    "img": "assets/s18_04.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_05",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "จอกแห่งดวงดาว",
    "img": "assets/s18_05.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_06",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "ขนนกฟีนิกซ์",
    "img": "assets/s18_06.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_07",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "นาฬิกาทรายแห่งดวงดาว",
    "img": "assets/s18_07.webp",
    "rarity": "legendary"
  },
  {
    "id": "s18_08",
    "set": 18,
    "setName": "ของตำนาน",
    "name": "กุญแจจักรวาล",
    "img": "assets/s18_08.webp",
    "rarity": "legendary"
  }
];
