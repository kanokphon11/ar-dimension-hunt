# AR Dimension Hunt v0.5 — เปิดออนไลน์ด้วย GitHub Pages

เวอร์ชันนี้ออกแบบให้หน้าเกมอยู่บน GitHub Pages (HTTPS) และใช้ Google Apps Script URL เดิมเป็น API/ฐานข้อมูลกลาง

## ไฟล์ที่ต้องอัปโหลด
อัปโหลด **ทุกไฟล์และโฟลเดอร์ในโฟลเดอร์นี้** ไปยัง root ของ repository โดยเฉพาะ `assets/` ซึ่งมีภาพของสะสม 136 ชิ้น

## ตั้งค่า GitHub Pages
1. สร้าง repository ใหม่ เช่น `ar-dimension-hunt`
2. อัปโหลดไฟล์ทั้งหมดในชุดนี้
3. เปิด **Settings → Pages**
4. Source เลือก **Deploy from a branch**
5. Branch เลือก `main` และโฟลเดอร์ `/ (root)` แล้ว Save
6. รอ GitHub แสดงลิงก์ HTTPS เช่น `https://USERNAME.github.io/ar-dimension-hunt/`
7. เปิดลิงก์จากมือถือ แล้วหน้า “ตรวจความพร้อมก่อนเริ่ม” ควรขึ้น ✅ ทั้ง HTTPS / GPS / กล้อง AR / ระบบกลาง

## Google Apps Script
ยังใช้ Web App เดิม:
`https://script.google.com/macros/s/AKfycbxbRE0tAZo3UnM-BVTV8S5RSTWn9UteZva_wN9t-LLtpB2EpTkNRz6xx_CAZHWp293B/exec`

ไม่ต้องเปลี่ยน Spreadsheet ID และไม่ต้องสร้างฐานข้อมูลใหม่

## สำคัญ
- บน Android แนะนำ Chrome
- บน iPhone ใช้ Safari และกด Allow เมื่อเว็บขอ Location/Camera
- ถ้ากล้องหรือ GPS ไม่ขึ้น ให้เช็กสถานะ 4 ช่องในหน้าแรกก่อน
