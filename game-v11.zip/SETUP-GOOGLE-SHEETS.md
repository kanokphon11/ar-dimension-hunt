# Google Sheet / GAS Setup — v0.3

ฐานข้อมูลถูกสร้างไว้แล้ว:
https://docs.google.com/spreadsheets/d/1b41QJBpfbSpUWzDUskvMK-O8Il7ikyN7jBV5LraSMik/edit

แท็บหลัก:
- Students — นักเรียนและสถิติ
- Spawns — จุดเกิดและช่วงเวลา
- Collections — ประวัติการเก็บ
- Config — ค่าระบบ
- Items — รายการไอเทม
- README — คำอธิบายในชีต

ให้ทำตาม `UPGRADE-v0.3.md` เพื่ออัปเดต Apps Script ก่อนใช้งานจริง
