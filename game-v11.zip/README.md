# AR Dimension Hunt v0.5 — GitHub Pages Ready

เกมล่าของสะสม AR รอบโรงเรียนสำหรับ ป.4–ป.6

## ระบบหลัก
- GPS / เรดาร์ / แผนที่ภารกิจ
- กล้อง AR
- Dimension Lock โจทย์คณิตศาสตร์คำตอบ 0–999
- ของสะสม 18 เซ็ต 136 ชิ้น
- Common / Rare / Epic / Legendary
- กระเป๋า 4 มิติ + Dimension Dex
- Daily Missions
- Timed Spawns + Legendary Alert
- Teacher Mode สำหรับวางจุดเกิดจริง
- Google Apps Script + Google Sheet เป็นฐานข้อมูลกลาง
- JSONP fallback สำหรับเชื่อม API จาก static hosting
- หน้า Preflight ตรวจ HTTPS / GPS / Camera / API

## เปิดออนไลน์
อ่าน `DEPLOY-GITHUB-PAGES.md`

## Backend
`Code.gs` คือ backend เวอร์ชัน 0.5 และใช้ Spreadsheet เดิม
