# อัปเกรด Apps Script เป็น v0.3

1. เปิด Google Sheet `AR Dimension Hunt - Database`
2. ไปที่ **ส่วนขยาย > Apps Script**
3. เปิดไฟล์ `Code.gs`
4. เลือกทั้งหมด แล้วแทนที่ด้วยไฟล์ `Code.gs` จากแพ็ก v0.3
5. กด Save
6. รัน `setupARDimensionHunt` 1 ครั้ง และอนุญาตสิทธิ์ถ้ามีการถาม
7. ไปที่ **Deploy > Manage deployments**
8. กดรูปดินสอแก้ Deployment เดิม
9. Version เลือก **New version**
10. กด **Deploy**

หากแก้ Deployment เดิม URL `/exec` จะคงเดิม เกมจึงไม่ต้องแก้ config.js ใหม่

## ฟิลด์ Spawn ใหม่
- `startHour` 0–23
- `endHour` 1–24
- `dayMode` = `all`, `weekdays`, `weekend`

จุดเกิดเก่าที่ไม่มีค่าใหม่จะถูกมองเป็น **ทุกวัน / ทั้งวัน** โดยอัตโนมัติ
