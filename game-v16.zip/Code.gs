// AR Dimension Hunt — connected database build
const DATABASE_SPREADSHEET_ID = '1b41QJBpfbSpUWzDUskvMK-O8Il7ikyN7jBV5LraSMik';
function getDB_() { return SpreadsheetApp.openById(DATABASE_SPREADSHEET_ID); }

const APP = {
  TZ: 'Asia/Bangkok',
  SHEETS: {
    students: 'Students',
    spawns: 'Spawns',
    collections: 'Collections',
    config: 'Config',
    crafting: 'Crafting',
    uses: 'Uses',
    questClaims: 'QuestClaims'
  },
  HEADERS: {
    Students: ['studentCode','name','grade','createdAt','lastSeen','totalCollects','uniqueItems'],
    Spawns: ['spawnId','lat','lng','itemId','radius','cooldownMs','active','label','createdAt','updatedAt','startHour','endHour','dayMode'],
    Collections: ['timestamp','date','studentCode','name','grade','spawnId','itemId','set','setName','itemName','question'],
    Config: ['key','value'],
    Crafting: ['timestamp','date','studentCode','recipeId','outputName','ingredientsJson'],
    Uses: ['timestamp','date','studentCode','kind','refId','effectKey','expiresAt','detailJson'],
    QuestClaims: ['timestamp','date','studentCode','questId','rewardTokens']
  }
};

const ITEM_META = {"s01_01":{"id":"s01_01","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลเปลวไฟ"},"s01_02":{"id":"s01_02","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลน้ำแข็ง"},"s01_03":{"id":"s01_03","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลสายลม"},"s01_04":{"id":"s01_04","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลแสง"},"s01_05":{"id":"s01_05","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลเวท"},"s01_06":{"id":"s01_06","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลจักรวาล"},"s01_07":{"id":"s01_07","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลสุริยะ"},"s01_08":{"id":"s01_08","set":1,"setName":"คริสตัลธาตุ","name":"คริสตัลสายฟ้า"},"s02_01":{"id":"s02_01","set":2,"setName":"ไข่มิติ","name":"ไข่พฤกษา"},"s02_02":{"id":"s02_02","set":2,"setName":"ไข่มิติ","name":"ไข่เงามิติ"},"s02_03":{"id":"s02_03","set":2,"setName":"ไข่มิติ","name":"ไข่สายฟ้า"},"s02_04":{"id":"s02_04","set":2,"setName":"ไข่มิติ","name":"ไข่ดารา"},"s02_05":{"id":"s02_05","set":2,"setName":"ไข่มิติ","name":"ไข่ท้องฟ้า"},"s02_06":{"id":"s02_06","set":2,"setName":"ไข่มิติ","name":"ไข่จักรวาล"},"s02_07":{"id":"s02_07","set":2,"setName":"ไข่มิติ","name":"ไข่มหาสมุทร"},"s02_08":{"id":"s02_08","set":2,"setName":"ไข่มิติ","name":"ไข่ศิลา"},"s03_01":{"id":"s03_01","set":3,"setName":"เหรียญโบราณ","name":"เหรียญจันทรา"},"s03_02":{"id":"s03_02","set":3,"setName":"เหรียญโบราณ","name":"เหรียญวิญญาณ"},"s03_03":{"id":"s03_03","set":3,"setName":"เหรียญโบราณ","name":"เหรียญเกลียวโบราณ"},"s03_04":{"id":"s03_04","set":3,"setName":"เหรียญโบราณ","name":"เหรียญสายฟ้า"},"s03_05":{"id":"s03_05","set":3,"setName":"เหรียญโบราณ","name":"เหรียญวายุ"},"s03_06":{"id":"s03_06","set":3,"setName":"เหรียญโบราณ","name":"เหรียญดารา"},"s03_07":{"id":"s03_07","set":3,"setName":"เหรียญโบราณ","name":"เหรียญจักรกล"},"s03_08":{"id":"s03_08","set":3,"setName":"เหรียญโบราณ","name":"เหรียญสุริยะ"},"s04_01":{"id":"s04_01","set":4,"setName":"ฟอสซิล","name":"ฟอสซิลกะโหลกไดโนเสาร์"},"s04_02":{"id":"s04_02","set":4,"setName":"ฟอสซิล","name":"ฟอสซิลไทรโลไบต์"},"s04_03":{"id":"s04_03","set":4,"setName":"ฟอสซิล","name":"ฟอสซิลใบไม้"},"s04_04":{"id":"s04_04","set":4,"setName":"ฟอสซิล","name":"อำพันแมลง"},"s04_05":{"id":"s04_05","set":4,"setName":"ฟอสซิล","name":"กรงเล็บโบราณ"},"s04_06":{"id":"s04_06","set":4,"setName":"ฟอสซิล","name":"ฟอสซิลแอมโมไนต์"},"s04_07":{"id":"s04_07","set":4,"setName":"ฟอสซิล","name":"ฟอสซิลปลาหิน"},"s04_08":{"id":"s04_08","set":4,"setName":"ฟอสซิล","name":"อำพันผลึก"},"s05_01":{"id":"s05_01","set":5,"setName":"ชิ้นส่วนจักรกล","name":"โมดูลวงจร"},"s05_02":{"id":"s05_02","set":5,"setName":"ชิ้นส่วนจักรกล","name":"เลนส์พลังงาน"},"s05_03":{"id":"s05_03","set":5,"setName":"ชิ้นส่วนจักรกล","name":"ข้อต่อแขนกล"},"s05_04":{"id":"s05_04","set":5,"setName":"ชิ้นส่วนจักรกล","name":"เฟืองโบราณ"},"s05_05":{"id":"s05_05","set":5,"setName":"ชิ้นส่วนจักรกล","name":"แกนพลาสมา"},"s05_06":{"id":"s05_06","set":5,"setName":"ชิ้นส่วนจักรกล","name":"แผงควบคุม"},"s05_07":{"id":"s05_07","set":5,"setName":"ชิ้นส่วนจักรกล","name":"เครื่องกำเนิดพลังงาน"},"s05_08":{"id":"s05_08","set":5,"setName":"ชิ้นส่วนจักรกล","name":"เฟืองคริสตัล"},"s06_01":{"id":"s06_01","set":6,"setName":"เศษดาว","name":"ผลึกดาวน้ำแข็ง"},"s06_02":{"id":"s06_02","set":6,"setName":"เศษดาว","name":"เศษดาวจักรวาล"},"s06_03":{"id":"s06_03","set":6,"setName":"เศษดาว","name":"ดาวหาง"},"s06_04":{"id":"s06_04","set":6,"setName":"เศษดาว","name":"เศษผลึกกาแล็กซี"},"s06_05":{"id":"s06_05","set":6,"setName":"เศษดาว","name":"ผลึกดาวทอง"},"s06_06":{"id":"s06_06","set":6,"setName":"เศษดาว","name":"คริสตัลจักรวาลม่วง"},"s06_07":{"id":"s06_07","set":6,"setName":"เศษดาว","name":"คริสตัลดารา"},"s06_08":{"id":"s06_08","set":6,"setName":"เศษดาว","name":"ผลึกสุริยะ"},"s07_01":{"id":"s07_01","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วจันทรา"},"s07_02":{"id":"s07_02","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วเถาวัลย์"},"s07_03":{"id":"s07_03","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วน้ำแข็ง"},"s07_04":{"id":"s07_04","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วสุริยะ"},"s07_05":{"id":"s07_05","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วอาคม"},"s07_06":{"id":"s07_06","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วหัวใจ"},"s07_07":{"id":"s07_07","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วสายฟ้า"},"s07_08":{"id":"s07_08","set":7,"setName":"ลูกแก้วเวทมนตร์","name":"ลูกแก้วแรงโน้มถ่วง"},"s08_01":{"id":"s08_01","set":8,"setName":"พืชวิเศษ","name":"ดอกไม้เพลิงฟีนิกซ์"},"s08_02":{"id":"s08_02","set":8,"setName":"พืชวิเศษ","name":"ดอกจันทราคริสตัล"},"s08_03":{"id":"s08_03","set":8,"setName":"พืชวิเศษ","name":"เห็ดสายรุ้ง"},"s08_04":{"id":"s08_04","set":8,"setName":"พืชวิเศษ","name":"กล้วยไม้สายฟ้า"},"s08_05":{"id":"s08_05","set":8,"setName":"พืชวิเศษ","name":"เฟิร์นน้ำแข็ง"},"s08_06":{"id":"s08_06","set":8,"setName":"พืชวิเศษ","name":"กระบองเพชรมรกต"},"s08_07":{"id":"s08_07","set":8,"setName":"พืชวิเศษ","name":"ผลสุริยะ"},"s08_08":{"id":"s08_08","set":8,"setName":"พืชวิเศษ","name":"ดอกบัวจักรวาล"},"s09_01":{"id":"s09_01","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"มัดสมุนไพร"},"s09_02":{"id":"s09_02","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"ลูกโอ๊กทอง"},"s09_03":{"id":"s09_03","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"โคนสนอำพัน"},"s09_04":{"id":"s09_04","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"รวงน้ำผึ้ง"},"s09_05":{"id":"s09_05","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"หอยมุกสายรุ้ง"},"s09_06":{"id":"s09_06","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"ขนนกยูงวิเศษ"},"s09_07":{"id":"s09_07","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"ฝักเมล็ดอำพัน"},"s09_08":{"id":"s09_08","set":9,"setName":"วัตถุดิบธรรมชาติ","name":"พวงเบอร์รีเวท"},"s10_01":{"id":"s10_01","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"ภูตใบไม้"},"s10_02":{"id":"s10_02","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"มังกรผีเสื้อ"},"s10_03":{"id":"s10_03","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"ภูตเห็ด"},"s10_04":{"id":"s10_04","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"ภูตหยดน้ำ"},"s10_05":{"id":"s10_05","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"ภูตหิ่งห้อย"},"s10_06":{"id":"s10_06","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"โกเลมหินน้อย"},"s10_07":{"id":"s10_07","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"ด้วงคริสตัล"},"s10_08":{"id":"s10_08","set":10,"setName":"สิ่งมีชีวิตจิ๋ว","name":"ภูตเมฆ"},"s11_01":{"id":"s11_01","set":11,"setName":"หีบลึกลับ","name":"หีบสุริยันเพลิง"},"s11_02":{"id":"s11_02","set":11,"setName":"หีบลึกลับ","name":"หีบจันทราคริสตัล"},"s11_03":{"id":"s11_03","set":11,"setName":"หีบลึกลับ","name":"หีบพงไพร"},"s11_04":{"id":"s11_04","set":11,"setName":"หีบลึกลับ","name":"หีบราชินีแห่งทะเล"},"s11_05":{"id":"s11_05","set":11,"setName":"หีบลึกลับ","name":"หีบต้องสาป"},"s11_06":{"id":"s11_06","set":11,"setName":"หีบลึกลับ","name":"หีบจักรวาล"},"s12_01":{"id":"s12_01","set":12,"setName":"หนังสือความรู้","name":"หนังสือธาตุไฟ"},"s12_02":{"id":"s12_02","set":12,"setName":"หนังสือความรู้","name":"หนังสือธาตุน้ำ"},"s12_03":{"id":"s12_03","set":12,"setName":"หนังสือความรู้","name":"หนังสือพฤกษา"},"s12_04":{"id":"s12_04","set":12,"setName":"หนังสือความรู้","name":"หนังสือแสงสุริยะ"},"s12_05":{"id":"s12_05","set":12,"setName":"หนังสือความรู้","name":"หนังสือเวทมนตร์ลึกลับ"},"s12_06":{"id":"s12_06","set":12,"setName":"หนังสือความรู้","name":"หนังสือความรู้โบราณ"},"s13_01":{"id":"s13_01","set":13,"setName":"อัญมณีธาตุพิเศษ","name":"ทับทิมเพลิง"},"s13_02":{"id":"s13_02","set":13,"setName":"อัญมณีธาตุพิเศษ","name":"อัญมณีวังวนน้ำ"},"s13_03":{"id":"s13_03","set":13,"setName":"อัญมณีธาตุพิเศษ","name":"มรกตพิภพ"},"s13_04":{"id":"s13_04","set":13,"setName":"อัญมณีธาตุพิเศษ","name":"คริสตัลวายุ"},"s13_05":{"id":"s13_05","set":13,"setName":"อัญมณีธาตุพิเศษ","name":"คริสตัลทองคำ"},"s13_06":{"id":"s13_06","set":13,"setName":"อัญมณีธาตุพิเศษ","name":"คริสตัลจักรวาล"},"s14_01":{"id":"s14_01","set":14,"setName":"วัตถุจากต่างมิติ","name":"ลูกบาศก์พอร์ทัล"},"s14_02":{"id":"s14_02","set":14,"setName":"วัตถุจากต่างมิติ","name":"คริสตัลมิติ"},"s14_03":{"id":"s14_03","set":14,"setName":"วัตถุจากต่างมิติ","name":"แอสโทรเลบมิติ"},"s14_04":{"id":"s14_04","set":14,"setName":"วัตถุจากต่างมิติ","name":"เครื่องรางเกลียวมิติ"},"s14_05":{"id":"s14_05","set":14,"setName":"วัตถุจากต่างมิติ","name":"ลูกแก้วแรงโน้มถ่วง"},"s14_06":{"id":"s14_06","set":14,"setName":"วัตถุจากต่างมิติ","name":"ปริซึมจักรวาล"},"s14_07":{"id":"s14_07","set":14,"setName":"วัตถุจากต่างมิติ","name":"ออบลิสก์เหนือมิติ"},"s14_08":{"id":"s14_08","set":14,"setName":"วัตถุจากต่างมิติ","name":"นาฬิกาทรายจักรวาล"},"s15_01":{"id":"s15_01","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราราชันย์ดาวทอง"},"s15_02":{"id":"s15_02","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราคัมภีร์ดวงดาว"},"s15_03":{"id":"s15_03","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราต้นไม้มรกต"},"s15_04":{"id":"s15_04","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราศิลปะและดนตรี"},"s15_05":{"id":"s15_05","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราวิทยาศาสตร์อาคม"},"s15_06":{"id":"s15_06","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราเรขาคณิต"},"s15_07":{"id":"s15_07","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราชัยชนะ"},"s15_08":{"id":"s15_08","set":15,"setName":"ป้ายตราโรงเรียน","name":"ตราปีกแห่งดวงดาว"},"s16_01":{"id":"s16_01","set":16,"setName":"ขวดบันทึกความทรงจำ","name":"ขวดรุ่งอรุณโรงเรียน"},"s16_02":{"id":"s16_02","set":16,"setName":"ขวดบันทึกความทรงจำ","name":"ขวดหัวใจมิตรภาพ"},"s16_03":{"id":"s16_03","set":16,"setName":"ขวดบันทึกความทรงจำ","name":"ขวดความรู้"},"s16_04":{"id":"s16_04","set":16,"setName":"ขวดบันทึกความทรงจำ","name":"ขวดสนามเด็กเล่น"},"s16_05":{"id":"s16_05","set":16,"setName":"ขวดบันทึกความทรงจำ","name":"ขวดท่วงทำนอง"},"s16_06":{"id":"s16_06","set":16,"setName":"ขวดบันทึกความทรงจำ","name":"ขวดจักรวาล"},"s17_01":{"id":"s17_01","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราเปลวเพลิง"},"s17_02":{"id":"s17_02","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราวังวนน้ำแข็ง"},"s17_03":{"id":"s17_03","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราภูผามรกต"},"s17_04":{"id":"s17_04","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราวายุ"},"s17_05":{"id":"s17_05","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราสายฟ้า"},"s17_06":{"id":"s17_06","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราสุริยะ"},"s17_07":{"id":"s17_07","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราจันทราเพลิงม่วง"},"s17_08":{"id":"s17_08","set":17,"setName":"สัญลักษณ์แห่งพลัง","name":"ตราดวงตาจักรวาล"},"s18_01":{"id":"s18_01","set":18,"setName":"ของตำนาน","name":"โล่สุริยะศักดิ์สิทธิ์"},"s18_02":{"id":"s18_02","set":18,"setName":"ของตำนาน","name":"มงกุฎแห่งดวงดาว"},"s18_03":{"id":"s18_03","set":18,"setName":"ของตำนาน","name":"ดาบคริสตัลจักรวาล"},"s18_04":{"id":"s18_04","set":18,"setName":"ของตำนาน","name":"คทาจักรวาล"},"s18_05":{"id":"s18_05","set":18,"setName":"ของตำนาน","name":"จอกแห่งดวงดาว"},"s18_06":{"id":"s18_06","set":18,"setName":"ของตำนาน","name":"ขนนกฟีนิกซ์"},"s18_07":{"id":"s18_07","set":18,"setName":"ของตำนาน","name":"นาฬิกาทรายแห่งดวงดาว"},"s18_08":{"id":"s18_08","set":18,"setName":"ของตำนาน","name":"กุญแจจักรวาล"}};

const CRAFT_RECIPES = {
  mix_fire_tonic:{name:'น้ำยาพลังเพลิง',ingredients:{s01_01:1,s09_01:1},effect:'radar_boost',durationMin:30},
  mix_frost_core:{name:'แกนน้ำแข็ง',ingredients:{s01_02:1,s06_01:1},effect:'cooldown_half',durationMin:30},
  mix_storm_orb:{name:'ลูกแก้วพายุ',ingredients:{s01_08:1,s07_07:1},effect:'capture_boost',durationMin:30},
  mix_star_orb:{name:'ลูกแก้วดารา',ingredients:{s06_02:1,s07_05:1},effect:'star_sight',durationMin:30},
  mix_ancient_core:{name:'แกนจักรกลโบราณ',ingredients:{s04_02:1,s05_04:1},effect:'trader_bonus',durationMin:30},
  mix_solar_seed:{name:'เมล็ดสุริยะ',ingredients:{s08_07:1,s01_07:1},effect:'radar_small',durationMin:60},
  mix_moon_elixir:{name:'น้ำยาจันทรา',ingredients:{s03_01:1,s07_01:1},effect:'capture_small',durationMin:60},
  mix_knowledge_seal:{name:'ตราความรู้มิติ',ingredients:{s12_06:1,s15_02:1},effect:'math_hint',durationMin:30},
  mix_portal_key:{name:'กุญแจพอร์ทัล',ingredients:{s14_01:1,s14_02:1},effect:'portal',durationMin:0},
  mix_phoenix_flame:{name:'เปลวเพลิงฟีนิกซ์',ingredients:{s18_06:1,s13_01:1},effect:'legendary_sight',durationMin:30},
  mix_cosmic_compass:{name:'เข็มทิศจักรวาล',ingredients:{s06_04:1,s14_03:1},effect:'star_sight',durationMin:60,secret:true},
  mix_lucky_prism:{name:'ปริซึมโชคดี',ingredients:{s13_06:1,s14_06:1},effect:'trader_bonus',durationMin:60,secret:true},
  mix_time_sand:{name:'ทรายเวลามิติ',ingredients:{s14_08:1,s18_07:1},effect:'cooldown_half',durationMin:60,secret:true}
};

const STORY_QUESTS = {
  q1:{title:'บทที่ 1 • ประตูสู่โลกเวทมนตร์',desc:'เก็บไอเทมให้ได้อย่างน้อย 3 ชิ้น',reward:1},
  q2:{title:'บทที่ 2 • นักสะสมฝึกหัด',desc:'ค้นพบไอเทมอย่างน้อย 5 ชนิด',reward:1},
  q3:{title:'บทที่ 3 • เวิร์กช็อปแห่งดวงดาว',desc:'ผสมไอเทมสำเร็จอย่างน้อย 1 ครั้ง',reward:2},
  q4:{title:'บทที่ 4 • พบพ่อค้าแห่งมิติ',desc:'แลกของกับพ่อค้าอย่างน้อย 1 ครั้ง',reward:2},
  q5:{title:'บทที่ 5 • Collection Master',desc:'สะสมครบอย่างน้อย 1 เซ็ต',reward:3}
};
const SHOP_ITEMS = {
  shop_herb:{itemId:'s09_01',name:'มัดสมุนไพร',price:1},
  shop_moon_coin:{itemId:'s03_01',name:'เหรียญจันทรา',price:1},
  shop_star_fragment:{itemId:'s06_02',name:'เศษดาวจักรวาล',price:2},
  shop_magic_orb:{itemId:'s07_05',name:'ลูกแก้วอาคม',price:2},
  shop_dim_crystal:{itemId:'s14_02',name:'คริสตัลมิติ',price:3}
};

function setupARDimensionHunt() {
  const ss = getDB_();
  Object.keys(APP.HEADERS).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const headers = APP.HEADERS[name];
    sh.getRange(1,1,1,headers.length).setValues([headers]);
    sh.setFrozenRows(1);
  });
  const cfg = ss.getSheetByName(APP.SHEETS.config);
  const existing = readConfig_();
  if (!existing.TEACHER_CODE) cfg.appendRow(['TEACHER_CODE','2468']);
  if (!existing.ALLOW_SELF_REGISTER) cfg.appendRow(['ALLOW_SELF_REGISTER','TRUE']);
  if (!existing.SCHOOL_NAME) cfg.appendRow(['SCHOOL_NAME','โรงเรียนชุมชนบ้านหนองหญ้าปล้อง']);
  if (!existing.LEGENDARY_ALERT_RADIUS_M) cfg.appendRow(['LEGENDARY_ALERT_RADIUS_M','250']);
  if (!existing.DAILY_COLLECT_GOAL) cfg.appendRow(['DAILY_COLLECT_GOAL','3']);
  if (!existing.DAILY_RARE_GOAL) cfg.appendRow(['DAILY_RARE_GOAL','1']);
  return 'พร้อมใช้งานแล้ว';
}

function doGet(e) {
  try {
    setupIfNeeded_();
    const params = (e && e.parameter) || {};
    let body = {};
    if (params.payload) {
      try { body = JSON.parse(String(params.payload)); }
      catch (_) { throw new Error('payload ไม่ถูกต้อง'); }
    } else if (params.action) {
      body = Object.assign({}, params);
    }
    if (body.action || params.action) {
      const action = String(body.action || params.action || '');
      const out = handleAction_(action, body);
      return jsonOrJsonp_(e, Object.assign({ok:true}, out || {}));
    }
    return jsonOrJsonp_(e, {ok:true, app:'AR Dimension Hunt', version:'1.6-story-shop', message:'API พร้อมใช้งาน'});
  } catch (err) {
    return jsonOrJsonp_(e, {ok:false, error:String(err && err.message ? err.message : err)});
  }
}

function doPost(e) {
  try {
    setupIfNeeded_();
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(body.action || '');
    const out = handleAction_(action, body);
    return json_(Object.assign({ok:true}, out || {}));
  } catch (err) {
    return json_({ok:false, error:String(err && err.message ? err.message : err)});
  }
}

function handleAction_(action, body) {
  switch (String(action || '')) {
    case 'bootstrap': return bootstrap_(body);
    case 'collect': return collect_(body);
    case 'craft': return craft_(body);
    case 'useCraft': return useCraft_(body);
    case 'exchange': return exchange_(body);
    case 'openPortal': return openPortal_(body);
    case 'claimQuest': return claimQuest_(body);
    case 'buyShop': return buyShop_(body);
    case 'leaderboard': return {leaderboard: leaderboard_()};
    case 'teacherOverview': return teacherOverview_(body);
    case 'saveSpawn': return saveSpawn_(body);
    case 'deleteSpawn': return deleteSpawn_(body);
    default: throw new Error('ไม่รู้จัก action: ' + action);
  }
}

function jsonOrJsonp_(e, obj) {
  const cb = String(e && e.parameter && e.parameter.callback || '');
  if (cb && /^[A-Za-z_$][0-9A-Za-z_$\.]*$/.test(cb)) {
    return ContentService.createTextOutput(cb + '(' + JSON.stringify(obj) + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return json_(obj);
}

function bootstrap_(p) {
  const code = cleanCode_(p.studentCode);
  if (!code) throw new Error('กรุณาระบุรหัสนักเรียน');
  const student = upsertStudent_(code, p.name, p.grade);
  const summary = studentSummary_(code);
  return {
    student,
    spawns: readSpawns_(),
    inventory: summary.inventory,
    crafted: summary.crafted,
    tokens: summary.tokens,
    activeEffects: summary.activeEffects,
    quests: storyQuestState_(code, summary),
    shop: shopPublic_(),
    collected: summary.collected,
    todayCount: summary.todayCount,
    todayStats: summary.todayStats,
    leaderboard: leaderboard_(),
    config: publicConfig_()
  };
}

function collect_(p) {
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const code = cleanCode_(p.studentCode);
    if (!code) throw new Error('ไม่พบรหัสนักเรียน');
    const student = getStudent_(code);
    if (!student) throw new Error('ไม่พบบัญชีนักเรียน');
    const spawn = getSpawn_(String(p.spawnId || ''));
    if (!spawn || spawn.active === false) throw new Error('จุดเกิดนี้ไม่พร้อมใช้งาน');
    if (String(spawn.itemId) !== String(p.itemId || '')) throw new Error('ข้อมูลวัตถุไม่ตรงกับจุดเกิด');
    if (!spawnWindowActive_(spawn)) throw new Error('จุดเกิดนี้ยังไม่อยู่ในช่วงเวลาที่กำหนด');

    const last = lastCollectionAt_(code, spawn.spawnId);
    const preSummary=studentSummary_(code); const cooldown = Number(spawn.cooldown || 86400000) * ((preSummary.activeEffects.cooldown_half&&preSummary.activeEffects.cooldown_half>Date.now()) ? 0.5 : 1);
    if (last && Date.now() - last < cooldown) {
      const mins = Math.ceil((cooldown - (Date.now() - last))/60000);
      throw new Error('จุดนี้ยังไม่เกิดใหม่ เหลือประมาณ ' + mins + ' นาที');
    }

    const item = itemMeta_(String(p.itemId || ''));
    const now = new Date();
    const sh = getDB_().getSheetByName(APP.SHEETS.collections);
    sh.appendRow([
      now,
      Utilities.formatDate(now, APP.TZ, 'yyyy-MM-dd'),
      code,
      student.name,
      student.grade,
      spawn.spawnId,
      item.id,
      item.set,
      item.setName,
      item.name,
      String(p.question || '')
    ]);
    updateStudentStats_(code);
    const summary = studentSummary_(code);
    return {
      inventory: summary.inventory,
      crafted: summary.crafted,
      tokens: summary.tokens,
      activeEffects: summary.activeEffects,
      collected: summary.collected,
      todayCount: summary.todayCount,
      todayStats: summary.todayStats,
      leaderboard: leaderboard_()
    };
  } finally {
    lock.releaseLock();
  }
}

function craft_(p) {
  const lock = LockService.getScriptLock(); lock.waitLock(15000);
  try {
    const code=cleanCode_(p.studentCode); if(!code)throw new Error('ไม่พบรหัสนักเรียน');
    const recipe=CRAFT_RECIPES[String(p.recipeId||'')]; if(!recipe)throw new Error('ไม่พบสูตรผสม');
    const summary=studentSummary_(code);
    Object.keys(recipe.ingredients).forEach(id=>{if((summary.inventory[id]||0)<recipe.ingredients[id])throw new Error('วัตถุดิบไม่เพียงพอ');});
    const now=new Date(); const sh=getDB_().getSheetByName(APP.SHEETS.crafting);
    sh.appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,String(p.recipeId),recipe.name,JSON.stringify(recipe.ingredients)]);
    const out=studentSummary_(code); return {inventory:out.inventory,crafted:out.crafted,tokens:out.tokens,activeEffects:out.activeEffects};
  } finally { lock.releaseLock(); }
}


function useCraft_(p) {
  const lock=LockService.getScriptLock(); lock.waitLock(15000);
  try{
    const code=cleanCode_(p.studentCode); if(!code)throw new Error('ไม่พบรหัสนักเรียน');
    const rid=String(p.recipeId||''),recipe=CRAFT_RECIPES[rid]; if(!recipe)throw new Error('ไม่พบไอเทมคราฟต์');
    if(recipe.effect==='portal')throw new Error('กุญแจพอร์ทัลต้องใช้ที่ประตูมิติ');
    const summary=studentSummary_(code); if((summary.crafted[rid]||0)<1)throw new Error('ไม่มีไอเทมนี้ให้ใช้');
    const now=new Date(),expires=new Date(now.getTime()+Math.max(1,Number(recipe.durationMin)||30)*60000);
    getDB_().getSheetByName(APP.SHEETS.uses).appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,'effect',rid,String(recipe.effect||''),expires,JSON.stringify({durationMin:recipe.durationMin||30})]);
    const out=studentSummary_(code); return {crafted:out.crafted,tokens:out.tokens,activeEffects:out.activeEffects};
  }finally{lock.releaseLock();}
}

function exchange_(p){
  const lock=LockService.getScriptLock(); lock.waitLock(15000);
  try{
    const code=cleanCode_(p.studentCode),itemId=String(p.itemId||''); if(!code||!ITEM_META[itemId])throw new Error('ข้อมูลแลกของไม่ครบ');
    const summary=studentSummary_(code); if((summary.inventory[itemId]||0)<3)throw new Error('ต้องมีของชนิดนี้อย่างน้อย 3 ชิ้น');
    const gain=summary.activeEffects.trader_bonus&&summary.activeEffects.trader_bonus>Date.now()?2:1;
    const now=new Date(),sh=getDB_().getSheetByName(APP.SHEETS.crafting);
    sh.appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,'npc_exchange_'+gain,'เหรียญมิติ',JSON.stringify({[itemId]:3})]);
    const out=studentSummary_(code); return {inventory:out.inventory,tokens:out.tokens,activeEffects:out.activeEffects};
  }finally{lock.releaseLock();}
}

function openPortal_(p){
  const lock=LockService.getScriptLock(); lock.waitLock(15000);
  try{
    const code=cleanCode_(p.studentCode); if(!code)throw new Error('ไม่พบรหัสนักเรียน');
    const summary=studentSummary_(code); if((summary.crafted.mix_portal_key||0)<1)throw new Error('ไม่มีกุญแจพอร์ทัล');
    const student=getStudent_(code); if(!student)throw new Error('ไม่พบบัญชีนักเรียน');
    const now=new Date(),ush=getDB_().getSheetByName(APP.SHEETS.uses);
    ush.appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,'portal','mix_portal_key','portal',now,JSON.stringify({})]);
    const ids=Object.keys(ITEM_META),rare=ids.filter(id=>rarityForItem_(id)==='rare'),epic=ids.filter(id=>rarityForItem_(id)==='epic'),legend=ids.filter(id=>rarityForItem_(id)==='legendary');
    const roll=Math.random(); const pool=roll<.62?rare:roll<.92?epic:legend; const item=itemMeta_(pool[Math.floor(Math.random()*pool.length)]||ids[0]);
    getDB_().getSheetByName(APP.SHEETS.collections).appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,student.name,student.grade,'portal_'+now.getTime(),item.id,item.set,item.setName,item.name,'รางวัลจากประตูมิติ']);
    updateStudentStats_(code);
    const out=studentSummary_(code); return {inventory:out.inventory,crafted:out.crafted,tokens:out.tokens,activeEffects:out.activeEffects,rewardId:item.id,rewardName:item.name,rewardRarity:rarityForItem_(item.id)};
  }finally{lock.releaseLock();}
}

function shopPublic_(){
  return Object.keys(SHOP_ITEMS).map(id=>({id:id,itemId:SHOP_ITEMS[id].itemId,name:SHOP_ITEMS[id].name,price:SHOP_ITEMS[id].price}));
}
function questClaimedSet_(code){
  const sh=getDB_().getSheetByName(APP.SHEETS.questClaims); if(!sh)return {};
  const out={}; sheetObjects_(sh).filter(r=>cleanCode_(r.studentCode)===code).forEach(r=>out[String(r.questId||'')]=true); return out;
}
function completedSetCountFromInventory_(inventory){
  const sets={}; Object.keys(ITEM_META).forEach(id=>{const m=ITEM_META[id];(sets[m.set]||(sets[m.set]=[])).push(id);});
  return Object.keys(sets).filter(k=>sets[k].every(id=>(inventory[id]||0)>0)).length;
}
function storyQuestState_(code, summary){
  const claimed=questClaimedSet_(code);
  const crows=sheetObjects_(getDB_().getSheetByName(APP.SHEETS.crafting)).filter(r=>cleanCode_(r.studentCode)===code);
  const craftCount=crows.filter(r=>!!CRAFT_RECIPES[String(r.recipeId||'')]).length;
  const exchangeCount=crows.filter(r=>String(r.recipeId||'').indexOf('npc_exchange_')===0).length;
  const total=Object.values(summary.inventory||{}).reduce((a,b)=>a+(Number(b)||0),0);
  const unique=Object.keys(summary.inventory||{}).filter(id=>(summary.inventory[id]||0)>0).length;
  const setCount=completedSetCountFromInventory_(summary.inventory||{});
  const done={q1:total>=3,q2:unique>=5,q3:craftCount>=1,q4:exchangeCount>=1,q5:setCount>=1};
  return Object.keys(STORY_QUESTS).map(id=>({id:id,title:STORY_QUESTS[id].title,desc:STORY_QUESTS[id].desc,reward:STORY_QUESTS[id].reward,done:!!done[id],claimed:!!claimed[id]}));
}
function claimQuest_(p){
  const lock=LockService.getScriptLock(); lock.waitLock(15000);
  try{
    const code=cleanCode_(p.studentCode),qid=String(p.questId||''); if(!code||!STORY_QUESTS[qid])throw new Error('ไม่พบเควสต์');
    const summary=studentSummary_(code),state=storyQuestState_(code,summary).find(q=>q.id===qid); if(!state||!state.done)throw new Error('เควสต์ยังไม่สำเร็จ'); if(state.claimed)throw new Error('รับรางวัลแล้ว');
    const now=new Date(),reward=Number(STORY_QUESTS[qid].reward)||0; getDB_().getSheetByName(APP.SHEETS.questClaims).appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,qid,reward]);
    const out=studentSummary_(code); return {tokens:out.tokens,quests:storyQuestState_(code,out)};
  }finally{lock.releaseLock();}
}
function buyShop_(p){
  const lock=LockService.getScriptLock(); lock.waitLock(15000);
  try{
    const code=cleanCode_(p.studentCode),sid=String(p.shopId||''),shop=SHOP_ITEMS[sid]; if(!code||!shop)throw new Error('ไม่พบสินค้า');
    const student=getStudent_(code); if(!student)throw new Error('ไม่พบบัญชีนักเรียน');
    const summary=studentSummary_(code); if((summary.tokens||0)<shop.price)throw new Error('เหรียญมิติไม่พอ');
    const now=new Date();
    getDB_().getSheetByName(APP.SHEETS.crafting).appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,'shop_spend_'+shop.price,shop.name,JSON.stringify({})]);
    const item=itemMeta_(shop.itemId); getDB_().getSheetByName(APP.SHEETS.collections).appendRow([now,Utilities.formatDate(now,APP.TZ,'yyyy-MM-dd'),code,student.name,student.grade,'shop_'+now.getTime(),item.id,item.set,item.setName,item.name,'ซื้อจากร้านเวทมนตร์']);
    updateStudentStats_(code); const out=studentSummary_(code); return {inventory:out.inventory,tokens:out.tokens,quests:storyQuestState_(code,out)};
  }finally{lock.releaseLock();}
}

function teacherOverview_(p) {
  requireTeacher_(p.teacherCode);
  const ss = getDB_();
  const sSh = ss.getSheetByName(APP.SHEETS.students);
  const cSh = ss.getSheetByName(APP.SHEETS.collections);
  const today = Utilities.formatDate(new Date(), APP.TZ, 'yyyy-MM-dd');
  const rows = sheetObjects_(cSh);
  return {
    spawns: readSpawns_(),
    stats: {
      students: Math.max(0, sSh.getLastRow()-1),
      collections: Math.max(0, cSh.getLastRow()-1),
      today: rows.filter(r => String(r.date) === today).length
    }
  };
}

function saveSpawn_(p) {
  requireTeacher_(p.teacherCode);
  const s = p.spawn || {};
  if (!s.id || !isFinite(Number(s.lat)) || !isFinite(Number(s.lng)) || !s.itemId) throw new Error('ข้อมูลจุดเกิดไม่ครบ');
  const sh = getDB_().getSheetByName(APP.SHEETS.spawns);
  const rows = sheetObjects_(sh);
  const found = rows.find(r => String(r.spawnId) === String(s.id));
  const now = new Date();
  const vals = [
    String(s.id), Number(s.lat), Number(s.lng), String(s.itemId),
    Math.max(5, Math.min(50, Number(s.radius)||18)),
    Math.max(3600000, Number(s.cooldown)||86400000),
    s.active === false ? false : true,
    String(s.label || ''),
    found && found.createdAt ? found.createdAt : now,
    now,
    Math.max(0, Math.min(23, Number(s.startHour == null ? 0 : s.startHour))),
    Math.max(1, Math.min(24, Number(s.endHour == null ? 24 : s.endHour))),
    ['all','weekdays','weekend'].indexOf(String(s.dayMode || 'all')) >= 0 ? String(s.dayMode || 'all') : 'all'
  ];
  if (found) sh.getRange(found.__row,1,1,vals.length).setValues([vals]);
  else sh.appendRow(vals);
  return {spawns:readSpawns_()};
}

function deleteSpawn_(p) {
  requireTeacher_(p.teacherCode);
  const id = String(p.spawnId || '');
  const sh = getDB_().getSheetByName(APP.SHEETS.spawns);
  const rows = sheetObjects_(sh);
  const found = rows.find(r => String(r.spawnId) === id);
  if (!found) throw new Error('ไม่พบจุดเกิด');
  sh.deleteRow(found.__row);
  return {spawns:readSpawns_()};
}

function upsertStudent_(code, name, grade) {
  const cfg = readConfig_();
  const sh = getDB_().getSheetByName(APP.SHEETS.students);
  const rows = sheetObjects_(sh);
  const found = rows.find(r => cleanCode_(r.studentCode) === code);
  const now = new Date();
  const cleanName = String(name || '').trim().slice(0,50) || ('นักเรียน ' + code);
  const cleanGrade = Math.max(4, Math.min(6, Number(grade)||4));
  if (!found) {
    if (String(cfg.ALLOW_SELF_REGISTER).toUpperCase() !== 'TRUE') throw new Error('รหัสนี้ยังไม่ได้ลงทะเบียน');
    sh.appendRow([code, cleanName, cleanGrade, now, now, 0, 0]);
  } else {
    sh.getRange(found.__row,2,1,4).setValues([[cleanName, cleanGrade, found.createdAt || now, now]]);
  }
  return getStudent_(code);
}

function getStudent_(code) {
  const rows = sheetObjects_(getDB_().getSheetByName(APP.SHEETS.students));
  const r = rows.find(x => cleanCode_(x.studentCode) === code);
  return r ? {code:cleanCode_(r.studentCode), name:String(r.name||''), grade:Number(r.grade)||4, total:Number(r.totalCollects)||0, unique:Number(r.uniqueItems)||0} : null;
}

function updateStudentStats_(code) {
  const sh = getDB_().getSheetByName(APP.SHEETS.students);
  const rows = sheetObjects_(sh);
  const found = rows.find(r => cleanCode_(r.studentCode) === code);
  if (!found) return;
  const cols = sheetObjects_(getDB_().getSheetByName(APP.SHEETS.collections)).filter(r => cleanCode_(r.studentCode) === code);
  const unique = new Set(cols.map(r => String(r.itemId))).size;
  sh.getRange(found.__row,5,1,3).setValues([[new Date(), cols.length, unique]]);
}

function studentSummary_(code) {
  const rows=sheetObjects_(getDB_().getSheetByName(APP.SHEETS.collections)).filter(r=>cleanCode_(r.studentCode)===code);
  const inv={},col={},crafted={},consumed={},usedCrafted={},activeEffects={}; let tokens=0;
  const today=Utilities.formatDate(new Date(),APP.TZ,'yyyy-MM-dd'); let todayCount=0; const todayStats={common:0,rare:0,epic:0,legendary:0};
  rows.forEach(r=>{const itemId=String(r.itemId||''),spawnId=String(r.spawnId||'');if(itemId)inv[itemId]=(inv[itemId]||0)+1;const ms=r.timestamp instanceof Date?r.timestamp.getTime():new Date(r.timestamp).getTime();if(spawnId&&isFinite(ms))col[spawnId]=Math.max(col[spawnId]||0,ms);if(String(r.date)===today){todayCount++;const rarity=rarityForItem_(itemId);todayStats[rarity]=(todayStats[rarity]||0)+1;}});
  const csh=getDB_().getSheetByName(APP.SHEETS.crafting);
  if(csh){sheetObjects_(csh).filter(r=>cleanCode_(r.studentCode)===code).forEach(r=>{
    const rid=String(r.recipeId||'');
    if(rid.indexOf('npc_exchange_')===0){tokens+=Number(rid.split('_').pop())||1;}
    else if(rid.indexOf('shop_spend_')===0){tokens-=Number(rid.split('_').pop())||0;}
    else if(rid&&CRAFT_RECIPES[rid])crafted[rid]=(crafted[rid]||0)+1;
    try{const ing=JSON.parse(String(r.ingredientsJson||'{}'));Object.keys(ing).forEach(id=>{if(id.indexOf('__')!==0)consumed[id]=(consumed[id]||0)+Number(ing[id]||0);});}catch(_){}
  });}
  const ush=getDB_().getSheetByName(APP.SHEETS.uses);
  if(ush){sheetObjects_(ush).filter(r=>cleanCode_(r.studentCode)===code).forEach(r=>{
    const kind=String(r.kind||''),ref=String(r.refId||''),key=String(r.effectKey||'');
    if((kind==='effect'||kind==='portal')&&ref)usedCrafted[ref]=(usedCrafted[ref]||0)+1;
    const exp=r.expiresAt instanceof Date?r.expiresAt.getTime():new Date(r.expiresAt).getTime();
    if(kind==='effect'&&key&&isFinite(exp)&&exp>Date.now())activeEffects[key]=Math.max(activeEffects[key]||0,exp);
  });}
  const qsh=getDB_().getSheetByName(APP.SHEETS.questClaims); if(qsh){sheetObjects_(qsh).filter(r=>cleanCode_(r.studentCode)===code).forEach(r=>{tokens+=Number(r.rewardTokens)||0;});}
  Object.keys(consumed).forEach(id=>inv[id]=Math.max(0,(inv[id]||0)-consumed[id]));
  Object.keys(usedCrafted).forEach(id=>crafted[id]=Math.max(0,(crafted[id]||0)-usedCrafted[id]));
  return {inventory:inv,crafted,tokens,activeEffects,collected:col,todayCount,todayStats};
}

function leaderboard_() {
  const rows = sheetObjects_(getDB_().getSheetByName(APP.SHEETS.students));
  return rows.map(r => ({
    code:cleanCode_(r.studentCode), name:String(r.name||''), grade:Number(r.grade)||4,
    total:Number(r.totalCollects)||0, unique:Number(r.uniqueItems)||0
  })).sort((a,b) => b.total-a.total || b.unique-a.unique || String(a.name).localeCompare(String(b.name))).slice(0,50);
}

function readSpawns_() {
  const rows = sheetObjects_(getDB_().getSheetByName(APP.SHEETS.spawns));
  return rows.map(r => ({
    id:String(r.spawnId||''), lat:Number(r.lat), lng:Number(r.lng), itemId:String(r.itemId||''),
    radius:Number(r.radius)||18, cooldown:Number(r.cooldownMs)||86400000,
    active: !(String(r.active).toUpperCase()==='FALSE' || r.active===false), label:String(r.label||''),
    startHour:isFinite(Number(r.startHour)) ? Number(r.startHour) : 0,
    endHour:isFinite(Number(r.endHour)) ? Number(r.endHour) : 24,
    dayMode:['all','weekdays','weekend'].indexOf(String(r.dayMode||'all')) >= 0 ? String(r.dayMode||'all') : 'all'
  })).filter(s => s.id && isFinite(s.lat) && isFinite(s.lng) && s.itemId && s.active);
}

function getSpawn_(id) {
  return readSpawns_().find(s => String(s.id) === String(id)) || null;
}

function lastCollectionAt_(code, spawnId) {
  const rows = sheetObjects_(getDB_().getSheetByName(APP.SHEETS.collections));
  let last = 0;
  rows.forEach(r => {
    if (cleanCode_(r.studentCode) === code && String(r.spawnId) === String(spawnId)) {
      const ms = r.timestamp instanceof Date ? r.timestamp.getTime() : new Date(r.timestamp).getTime();
      if (isFinite(ms)) last = Math.max(last, ms);
    }
  });
  return last;
}


function rarityForItem_(id) {
  const m = String(id || '').match(/^s(\d{2})_/);
  const setNo = m ? Number(m[1]) : 0;
  if (setNo === 18) return 'legendary';
  if ([13,14,17].indexOf(setNo) >= 0) return 'epic';
  if ([11,12,15,16].indexOf(setNo) >= 0) return 'rare';
  return 'common';
}

function spawnWindowActive_(spawn) {
  const now = new Date();
  const dayName = Utilities.formatDate(now, APP.TZ, 'EEE');
  const isWeekend = dayName === 'Sat' || dayName === 'Sun';
  const mode = String(spawn.dayMode || 'all');
  if (mode === 'weekdays' && isWeekend) return false;
  if (mode === 'weekend' && !isWeekend) return false;
  const hour = Number(Utilities.formatDate(now, APP.TZ, 'H')) + Number(Utilities.formatDate(now, APP.TZ, 'm'))/60;
  let start = Number(spawn.startHour), end = Number(spawn.endHour);
  if (!isFinite(start)) start = 0;
  if (!isFinite(end)) end = 24;
  if (start === end) return true;
  return start < end ? (hour >= start && hour < end) : (hour >= start || hour < end);
}

function publicConfig_() {
  const cfg = readConfig_();
  return {
    schoolName:String(cfg.SCHOOL_NAME || 'โรงเรียนชุมชนบ้านหนองหญ้าปล้อง'),
    legendaryAlertRadius:Number(cfg.LEGENDARY_ALERT_RADIUS_M) || 250,
    dailyCollectGoal:Number(cfg.DAILY_COLLECT_GOAL) || 3,
    dailyRareGoal:Number(cfg.DAILY_RARE_GOAL) || 1
  };
}

function requireTeacher_(code) {
  const cfg = readConfig_();
  if (String(code || '') !== String(cfg.TEACHER_CODE || '2468')) throw new Error('รหัสครูไม่ถูกต้อง');
}

function readConfig_() {
  const sh = getDB_().getSheetByName(APP.SHEETS.config);
  if (!sh || sh.getLastRow() < 2) return {};
  const vals = sh.getRange(2,1,sh.getLastRow()-1,2).getValues();
  const out = {};
  vals.forEach(r => { if (r[0] !== '') out[String(r[0])] = r[1]; });
  return out;
}

function sheetObjects_(sh) {
  if (!sh || sh.getLastRow() < 2) return [];
  const values = sh.getDataRange().getValues();
  const h = values.shift().map(String);
  return values.filter(r => r.some(v => v !== '')).map((r,i) => {
    const o = {__row:i+2}; h.forEach((k,j) => o[k]=r[j]); return o;
  });
}

function setupIfNeeded_() {
  const ss = getDB_();
  if (!ss.getSheetByName(APP.SHEETS.students) || !ss.getSheetByName(APP.SHEETS.spawns) || !ss.getSheetByName(APP.SHEETS.collections) || !ss.getSheetByName(APP.SHEETS.config) || !ss.getSheetByName(APP.SHEETS.crafting) || !ss.getSheetByName(APP.SHEETS.uses) || !ss.getSheetByName(APP.SHEETS.questClaims)) setupARDimensionHunt();
}

function cleanCode_(v) { return String(v == null ? '' : v).trim().replace(/[^0-9A-Za-z_-]/g,'').slice(0,20); }

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// รายการ 136 ชิ้นแบบย่อสำหรับบันทึกชื่อ/เซ็ตใน Collection sheet
function itemMeta_(id) {
  return ITEM_META[id] || {id:id,set:0,setName:'ไม่ทราบเซ็ต',name:id};
}
